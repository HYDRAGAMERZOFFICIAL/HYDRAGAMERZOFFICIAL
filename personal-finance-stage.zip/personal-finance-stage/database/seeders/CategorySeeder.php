<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Hardcode user_id to 2
        $userId = 2;
        $user = User::find($userId);
        
        if (!$user) {
            // If user with ID 2 doesn't exist, create it
            $user = User::create([
                'id' => $userId,
                'name' => 'Demo User',
                'email' => 'demo@example.com',
                'password' => Hash::make('password'),
                'email_verified_at' => now(),
            ]);
        }

        $this->createCategoriesForUser($user);
    }
    
    /**
     * Create categories for a specific user
     */
    public function createCategoriesForUser($user): void
    {
        // Check if user already has categories
        if ($user->categories()->count() > 0) {
            return; // Skip if user already has categories
        }
        
        // Expense categories with Indian context
        $expenseCategories = [
            [
                'name' => 'Groceries',
                'type' => 'expense',
                'color' => '#4CAF50',
                'description' => 'Daily groceries, vegetables, fruits, and household items',
            ],
            [
                'name' => 'Rent',
                'type' => 'expense',
                'color' => '#FF5722',
                'description' => 'Monthly house rent',
            ],
            [
                'name' => 'Transportation',
                'type' => 'expense',
                'color' => '#2196F3',
                'description' => 'Auto, bus, metro, train, and fuel expenses',
            ],
            [
                'name' => 'Utilities',
                'type' => 'expense',
                'color' => '#9C27B0',
                'description' => 'Electricity, water, gas, internet, and mobile bills',
            ],
            [
                'name' => 'Dining Out',
                'type' => 'expense',
                'color' => '#FFC107',
                'description' => 'Restaurants, cafes, and food delivery',
            ],
            [
                'name' => 'Entertainment',
                'type' => 'expense',
                'color' => '#E91E63',
                'description' => 'Movies, OTT subscriptions, and other entertainment',
            ],
            [
                'name' => 'Health',
                'type' => 'expense',
                'color' => '#00BCD4',
                'description' => 'Medical expenses, medicines, and health insurance',
            ],
            [
                'name' => 'Education',
                'type' => 'expense',
                'color' => '#795548',
                'description' => 'Tuition fees, books, courses, and educational materials',
            ],
        ];

        // Income categories
        $incomeCategories = [
            [
                'name' => 'Salary',
                'type' => 'income',
                'color' => '#4CAF50',
                'description' => 'Monthly salary and bonuses',
            ],
            [
                'name' => 'Investments',
                'type' => 'income',
                'color' => '#2196F3',
                'description' => 'Returns from stocks, mutual funds, FDs, and other investments',
            ],
            [
                'name' => 'Freelance',
                'type' => 'income',
                'color' => '#9C27B0',
                'description' => 'Income from freelance work and side projects',
            ],
            [
                'name' => 'Gifts',
                'type' => 'income',
                'color' => '#E91E63',
                'description' => 'Money received as gifts',
            ],
        ];

        // Create expense categories
        foreach ($expenseCategories as $category) {
            Category::create([
                'user_id' => $user->id,
                'name' => $category['name'],
                'type' => $category['type'],
                'color' => $category['color'],
                'description' => $category['description'],
            ]);
        }

        // Create income categories
        foreach ($incomeCategories as $category) {
            Category::create([
                'user_id' => $user->id,
                'name' => $category['name'],
                'type' => $category['type'],
                'color' => $category['color'],
                'description' => $category['description'],
            ]);
        }
    }
}