<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Budget;
use App\Models\Category;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;

class BudgetSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Hardcode user_id to 2
        $userId = 2;
        $user = User::find($userId);

        if (!$user) {
            // If user with ID 2 doesn't exist, create it
            $user = User::create([
                'id' => $userId,
                'name' => 'Demo User',
                'email' => 'demo@example.com',
                'password' => Hash::make('password'),
                'email_verified_at' => now(),
            ]);
        }

        $users = [$user];
        
        // Create budgets for each user
        foreach ($users as $user) {
            // Get all expense categories for this user
            $expenseCategories = Category::where('user_id', $user->id)
                ->where('type', 'expense')
                ->get();
            
            // If no categories exist for this user, run the CategorySeeder first
            if ($expenseCategories->isEmpty()) {
                // Create categories for this specific user
                $categorySeeder = new CategorySeeder();
                $categorySeeder->createCategoriesForUser($user);
                
                // Refresh categories
                $expenseCategories = Category::where('user_id', $user->id)
                    ->where('type', 'expense')
                    ->get();
            }
            
            // Skip if still no expense categories
            if ($expenseCategories->isEmpty()) {
                continue;
            }

            // Create monthly budgets for the current month
            $this->createCurrentMonthBudgets($user, $expenseCategories);
            
            // Create historical monthly budgets for the past year
            $this->createHistoricalMonthlyBudgets($user, $expenseCategories);
            
            // Create some quarterly budgets
            $this->createQuarterlyBudgets($user, $expenseCategories);
            
            // Create some annual budgets
            $this->createAnnualBudgets($user, $expenseCategories);
        }
    }

    /**
     * Create budgets for the current month
     */
    private function createCurrentMonthBudgets($user, $categories)
    {
        $startDate = Carbon::now()->startOfMonth();
        $endDate = Carbon::now()->endOfMonth();
        
        // Create budgets for each expense category
        foreach ($categories as $category) {
            // Skip some categories randomly to make it more realistic
            if (rand(1, 10) <= 2) { // 20% chance to skip
                continue;
            }
            
            // Set realistic budget amounts based on category
            $amount = $this->getBudgetAmountForCategory($category->name);
            
            Budget::create([
                'user_id' => $user->id,
                'category_id' => $category->id,
                'amount' => $amount,
                'period' => 'monthly',
                'start_date' => $startDate,
                'end_date' => $endDate,
            ]);
        }
    }

    /**
     * Create historical monthly budgets for the past year
     */
    private function createHistoricalMonthlyBudgets($user, $categories)
    {
        // Create monthly budgets for the past 11 months
        for ($i = 1; $i <= 11; $i++) {
            $startDate = Carbon::now()->subMonths($i)->startOfMonth();
            $endDate = Carbon::now()->subMonths($i)->endOfMonth();
            
            // Create budgets for a subset of categories each month
            foreach ($categories as $category) {
                // Skip some categories randomly
                if (rand(1, 10) <= 3) { // 30% chance to skip
                    continue;
                }
                
                // Set realistic budget amounts based on category
                $amount = $this->getBudgetAmountForCategory($category->name);
                
                // Add some variation to historical budgets
                $variationFactor = rand(85, 115) / 100; // 85% to 115%
                $amount = round($amount * $variationFactor, 2);
                
                Budget::create([
                    'user_id' => $user->id,
                    'category_id' => $category->id,
                    'amount' => $amount,
                    'period' => 'monthly',
                    'start_date' => $startDate,
                    'end_date' => $endDate,
                ]);
            }
        }
    }

    /**
     * Create quarterly budgets
     */
    private function createQuarterlyBudgets($user, $categories)
    {
        // Current quarter
        $currentQuarterStart = Carbon::now()->startOfQuarter();
        $currentQuarterEnd = Carbon::now()->endOfQuarter();
        
        // Previous quarter
        $prevQuarterStart = Carbon::now()->subQuarter()->startOfQuarter();
        $prevQuarterEnd = Carbon::now()->subQuarter()->endOfQuarter();
        
        // Select a few categories for quarterly budgets
        $quarterlyCategories = $categories->random(min(3, $categories->count()));
        
        foreach ($quarterlyCategories as $category) {
            // Current quarter budget
            $amount = $this->getBudgetAmountForCategory($category->name) * 3 * 0.9; // 90% of 3 months
            
            Budget::create([
                'user_id' => $user->id,
                'category_id' => $category->id,
                'amount' => $amount,
                'period' => 'quarterly',
                'start_date' => $currentQuarterStart,
                'end_date' => $currentQuarterEnd,
            ]);
            
            // Previous quarter budget
            $prevAmount = $amount * (rand(90, 110) / 100); // Slight variation
            
            Budget::create([
                'user_id' => $user->id,
                'category_id' => $category->id,
                'amount' => $prevAmount,
                'period' => 'quarterly',
                'start_date' => $prevQuarterStart,
                'end_date' => $prevQuarterEnd,
            ]);
        }
    }

    /**
     * Create annual budgets
     */
    private function createAnnualBudgets($user, $categories)
    {
        // Current year
        $currentYearStart = Carbon::now()->startOfYear();
        $currentYearEnd = Carbon::now()->endOfYear();
        
        // Previous year
        $prevYearStart = Carbon::now()->subYear()->startOfYear();
        $prevYearEnd = Carbon::now()->subYear()->endOfYear();
        
        // Select a few categories for annual budgets
        $annualCategories = $categories->random(min(2, $categories->count()));
        
        foreach ($annualCategories as $category) {
            // Current year budget
            $amount = $this->getBudgetAmountForCategory($category->name) * 12 * 0.8; // 80% of 12 months
            
            Budget::create([
                'user_id' => $user->id,
                'category_id' => $category->id,
                'amount' => $amount,
                'period' => 'annual',
                'start_date' => $currentYearStart,
                'end_date' => $currentYearEnd,
            ]);
            
            // Previous year budget
            $prevAmount = $amount * (rand(85, 95) / 100); // Slightly lower
            
            Budget::create([
                'user_id' => $user->id,
                'category_id' => $category->id,
                'amount' => $prevAmount,
                'period' => 'annual',
                'start_date' => $prevYearStart,
                'end_date' => $prevYearEnd,
            ]);
        }
    }

    /**
     * Get a realistic budget amount based on category name
     */
    private function getBudgetAmountForCategory($categoryName)
    {
        switch ($categoryName) {
            case 'Groceries':
                return rand(8000, 15000); // ₹8,000-15,000 per month
            
            case 'Rent':
                return rand(15000, 35000); // ₹15,000-35,000 per month
            
            case 'Transportation':
                return rand(3000, 8000); // ₹3,000-8,000 per month
            
            case 'Utilities':
                return rand(3000, 7000); // ₹3,000-7,000 per month
            
            case 'Dining Out':
                return rand(4000, 10000); // ₹4,000-10,000 per month
            
            case 'Entertainment':
                return rand(2000, 5000); // ₹2,000-5,000 per month
            
            case 'Health':
                return rand(3000, 8000); // ₹3,000-8,000 per month
            
            case 'Education':
                return rand(5000, 20000); // ₹5,000-20,000 per month
            
            default:
                return rand(3000, 10000); // Default range
        }
    }
}