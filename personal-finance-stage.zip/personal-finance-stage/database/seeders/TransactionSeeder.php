<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Transaction;
use App\Models\Category;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;

class TransactionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Hardcode user_id to 2
        $userId = 2;
        $user = User::find($userId);
        
        if (!$user) {
            // If user with ID 2 doesn't exist, create it
            $user = User::create([
                'id' => $userId,
                'name' => 'Demo User',
                'email' => 'demo@example.com',
                'password' => Hash::make('password'),
                'email_verified_at' => now(),
            ]);
        }

        // Get all categories for this user
        $expenseCategories = Category::where('user_id', $userId)
            ->where('type', 'expense')
            ->get();
        
        $incomeCategories = Category::where('user_id', $userId)
            ->where('type', 'income')
            ->get();

        // If no categories exist, run the CategorySeeder first
        if ($expenseCategories->isEmpty() || $incomeCategories->isEmpty()) {
            // Modify the CategorySeeder to use user_id 2
            $this->call(CategorySeeder::class);
            
            // Refresh categories
            $expenseCategories = Category::where('user_id', $userId)
                ->where('type', 'expense')
                ->get();
            
            $incomeCategories = Category::where('user_id', $userId)
                ->where('type', 'income')
                ->get();
        }

        // Define start and end dates for 2024-2025 (till March)
        $startDate = Carbon::createFromDate(2024, 1, 1);
        $endDate = Carbon::createFromDate(2025, 3, 31);

        // Create realistic expense transactions
        $this->createExpenseTransactions($user, $expenseCategories, $startDate, $endDate);

        // Create realistic income transactions
        $this->createIncomeTransactions($user, $incomeCategories, $startDate, $endDate);
    }

    /**
     * Create realistic expense transactions
     */
    private function createExpenseTransactions($user, $categories, $startDate, $endDate)
    {
        // Grocery transactions (frequent, smaller amounts)
        $groceryCategory = $categories->where('name', 'Groceries')->first();
        if ($groceryCategory) {
            // 1-2 times per week for a year (52-104 transactions) - reduced frequency
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                // Add 1-2 grocery trips per week (reduced from 2-3)
                $weeklyTrips = rand(1, 2);
                for ($i = 0; $i < $weeklyTrips; $i++) {
                    // Random day within the week
                    $transactionDate = clone $currentDate;
                    $transactionDate->addDays(rand(0, 6));
                    
                    if ($transactionDate <= $endDate) {
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $groceryCategory->id,
                            'amount' => rand(2000, 3000) + (rand(0, 99) / 100), // ₹2000-3000
                            'type' => 'expense',
                            'date' => $transactionDate,
                            'description' => $this->getRandomGroceryDescription(),
                        ]);
                    }
                }
                $currentDate->addWeek();
            }
        }

        // Rent (monthly, fixed amount)
        $rentCategory = $categories->where('name', 'Rent')->first();
        if ($rentCategory) {
            $rentAmount = 30000; // Fixed rent of ₹30,000
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                // Pay rent on 1st-5th of each month
                $rentDate = clone $currentDate;
                $rentDate->setDay(rand(1, 5));
                
                if ($rentDate >= $startDate && $rentDate <= $endDate) {
                    Transaction::create([
                        'user_id' => $user->id,
                        'category_id' => $rentCategory->id,
                        'amount' => $rentAmount,
                        'type' => 'expense',
                        'date' => $rentDate,
                        'description' => 'Monthly rent payment',
                    ]);
                }
                $currentDate->addMonth();
            }
        }

        // Transportation (less frequent, lower amounts)
        $transportCategory = $categories->where('name', 'Transportation')->first();
        if ($transportCategory) {
            // 8-12 transactions per month (reduced from 15-20)
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                $monthlyTrips = rand(8, 12);
                for ($i = 0; $i < $monthlyTrips; $i++) {
                    $transactionDate = clone $currentDate;
                    $transactionDate->addDays(rand(0, 29));
                    
                    if ($transactionDate <= $endDate) {
                        // Mix of auto, metro, fuel expenses
                        $transportType = rand(1, 3);
                        $amount = 0;
                        $description = '';
                        
                        switch ($transportType) {
                            case 1: // Auto
                                $amount = rand(80, 300) + (rand(0, 99) / 100); // Reduced from 100-400
                                $description = 'Auto ride';
                                break;
                            case 2: // Metro
                                $amount = rand(20, 80) + (rand(0, 99) / 100); // Reduced from 20-100
                                $description = 'Metro fare';
                                break;
                            case 3: // Fuel
                                $amount = rand(400, 1500) + (rand(0, 99) / 100); // Reduced from 500-2000
                                $description = 'Petrol/Diesel';
                                break;
                        }
                        
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $transportCategory->id,
                            'amount' => $amount,
                            'type' => 'expense',
                            'date' => $transactionDate,
                            'description' => $description,
                        ]);
                    }
                }
                $currentDate->addMonth();
            }
        }

        // Utilities (monthly, medium amounts)
        $utilitiesCategory = $categories->where('name', 'Utilities')->first();
        if ($utilitiesCategory) {
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                // Electricity bill (monthly)
                $electricityDate = clone $currentDate;
                $electricityDate->setDay(rand(10, 15));
                
                if ($electricityDate >= $startDate && $electricityDate <= $endDate) {
                    // Higher in summer months (March-July)
                    $month = $electricityDate->month;
                    $electricityAmount = ($month >= 3 && $month <= 7) 
                        ? rand(5000, 7000) + (rand(0, 99) / 100)  // Summer
                        : rand(3000, 5000) + (rand(0, 99) / 100); // Other seasons
                    
                    Transaction::create([
                        'user_id' => $user->id,
                        'category_id' => $utilitiesCategory->id,
                        'amount' => $electricityAmount,
                        'type' => 'expense',
                        'date' => $electricityDate,
                        'description' => 'Electricity bill',
                    ]);
                }
                
                // Water bill (monthly or bi-monthly)
                if ($currentDate->month % 2 == 0) { // Bi-monthly
                    $waterDate = clone $currentDate;
                    $waterDate->setDay(rand(15, 20));
                    
                    if ($waterDate >= $startDate && $waterDate <= $endDate) {
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $utilitiesCategory->id,
                            'amount' => rand(500, 1000) + (rand(0, 99) / 100),
                            'type' => 'expense',
                            'date' => $waterDate,
                            'description' => 'Water bill',
                        ]);
                    }
                }
                
                // Internet bill (monthly)
                $internetDate = clone $currentDate;
                $internetDate->setDay(rand(5, 10));
                
                if ($internetDate >= $startDate && $internetDate <= $endDate) {
                    Transaction::create([
                        'user_id' => $user->id,
                        'category_id' => $utilitiesCategory->id,
                        'amount' => rand(2000, 3000) + (rand(0, 99) / 100),
                        'type' => 'expense',
                        'date' => $internetDate,
                        'description' => 'Internet bill',
                    ]);
                }
                
                // Mobile bill (monthly)
                $mobileDate = clone $currentDate;
                $mobileDate->setDay(rand(20, 25));
                
                if ($mobileDate >= $startDate && $mobileDate <= $endDate) {
                    Transaction::create([
                        'user_id' => $user->id,
                        'category_id' => $utilitiesCategory->id,
                        'amount' => rand(1000, 2000) + (rand(0, 99) / 100),
                        'type' => 'expense',
                        'date' => $mobileDate,
                        'description' => 'Mobile recharge',
                    ]);
                }
                
                $currentDate->addMonth();
            }
        }

        // Dining Out (variable frequency, medium amounts)
        $diningCategory = $categories->where('name', 'Dining Out')->first();
        if ($diningCategory) {
            // 6-10 times per month
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                $monthlyDining = rand(6, 10);
                for ($i = 0; $i < $monthlyDining; $i++) {
                    $transactionDate = clone $currentDate;
                    $transactionDate->addDays(rand(0, 29));
                    
                    if ($transactionDate <= $endDate) {
                        // Weekend dining is usually more expensive
                        $isWeekend = in_array($transactionDate->dayOfWeek, [0, 6]); // Sunday or Saturday
                        $amount = $isWeekend 
                            ? rand(3000, 5000) + (rand(0, 99) / 100) // Weekend dining
                            : rand(1500, 3000) + (rand(0, 99) / 100);  // Weekday dining
                        
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $diningCategory->id,
                            'amount' => $amount,
                            'type' => 'expense',
                            'date' => $transactionDate,
                            'description' => $this->getRandomDiningDescription(),
                        ]);
                    }
                }
                $currentDate->addMonth();
            }
        }

        // Entertainment (less frequent, variable amounts)
        $entertainmentCategory = $categories->where('name', 'Entertainment')->first();
        if ($entertainmentCategory) {
            // 3-5 times per month
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                $monthlyEntertainment = rand(3, 5);
                for ($i = 0; $i < $monthlyEntertainment; $i++) {
                    $transactionDate = clone $currentDate;
                    $transactionDate->addDays(rand(0, 29));
                    
                    if ($transactionDate <= $endDate) {
                        // Mix of movies, OTT subscriptions, etc.
                        $entertainmentType = rand(1, 3);
                        $amount = 0;
                        $description = '';
                        
                        switch ($entertainmentType) {
                            case 1: // Movie tickets
                                $amount = rand(1500, 3000) + (rand(0, 99) / 100);
                                $description = 'Movie tickets';
                                break;
                            case 2: // OTT subscription
                                $amount = rand(1000, 2000) + (rand(0, 99) / 100);
                                $description = $this->getRandomOTTDescription();
                                break;
                            case 3: // Other entertainment
                                $amount = rand(2000, 4000) + (rand(0, 99) / 100);
                                $description = 'Entertainment';
                                break;
                        }
                        
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $entertainmentCategory->id,
                            'amount' => $amount,
                            'type' => 'expense',
                            'date' => $transactionDate,
                            'description' => $description,
                        ]);
                    }
                }
                $currentDate->addMonth();
            }
        }

        // Health (infrequent, variable amounts)
        $healthCategory = $categories->where('name', 'Health')->first();
        if ($healthCategory) {
            // 1-3 times per month
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                $monthlyHealth = rand(1, 3);
                for ($i = 0; $i < $monthlyHealth; $i++) {
                    $transactionDate = clone $currentDate;
                    $transactionDate->addDays(rand(0, 29));
                    
                    if ($transactionDate <= $endDate) {
                        // Mix of doctor visits, medicines, etc.
                        $healthType = rand(1, 3);
                        $amount = 0;
                        $description = '';
                        
                        switch ($healthType) {
                            case 1: // Doctor consultation
                                $amount = rand(2000, 4000) + (rand(0, 99) / 100);
                                $description = 'Doctor consultation';
                                break;
                            case 2: // Medicines
                                $amount = rand(1500, 3000) + (rand(0, 99) / 100);
                                $description = 'Medicines';
                                break;
                            case 3: // Health insurance
                                if (rand(1, 10) == 1) { // Less frequent
                                    $amount = rand(20000, 30000) + (rand(0, 99) / 100);
                                    $description = 'Health insurance premium';
                                } else {
                                    $amount = rand(2000, 4000) + (rand(0, 99) / 100);
                                    $description = 'Medical expenses';
                                }
                                break;
                        }
                        
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $healthCategory->id,
                            'amount' => $amount,
                            'type' => 'expense',
                            'date' => $transactionDate,
                            'description' => $description,
                        ]);
                    }
                }
                $currentDate->addMonth();
            }
        }

        // Education (infrequent, larger amounts)
        $educationCategory = $categories->where('name', 'Education')->first();
        if ($educationCategory) {
            // Quarterly tuition fees
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                if ($currentDate->month % 3 == 0) { // Every 3 months
                    $tuitionDate = clone $currentDate;
                    $tuitionDate->setDay(rand(1, 10));
                    
                    if ($tuitionDate >= $startDate && $tuitionDate <= $endDate) {
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $educationCategory->id,
                            'amount' => rand(15000, 30000) + (rand(0, 99) / 100),
                            'type' => 'expense',
                            'date' => $tuitionDate,
                            'description' => 'Tuition fees',
                        ]);
                    }
                }
                
                // Books and supplies (monthly)
                $booksDate = clone $currentDate;
                $booksDate->setDay(rand(10, 25));
                
                if ($booksDate >= $startDate && $booksDate <= $endDate && rand(1, 3) == 1) {
                    Transaction::create([
                        'user_id' => $user->id,
                        'category_id' => $educationCategory->id,
                        'amount' => rand(500, 2000) + (rand(0, 99) / 100),
                        'type' => 'expense',
                        'date' => $booksDate,
                        'description' => 'Books and educational materials',
                    ]);
                }
                
                // Online courses (occasional)
                if (rand(1, 4) == 1) { // 25% chance each month
                    $courseDate = clone $currentDate;
                    $courseDate->setDay(rand(1, 28));
                    
                    if ($courseDate >= $startDate && $courseDate <= $endDate) {
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $educationCategory->id,
                            'amount' => rand(1000, 5000) + (rand(0, 99) / 100),
                            'type' => 'expense',
                            'date' => $courseDate,
                            'description' => 'Online course subscription',
                        ]);
                    }
                }
                
                $currentDate->addMonth();
            }
        }
    }

    /**
     * Create realistic income transactions
     */
    private function createIncomeTransactions($user, $categories, $startDate, $endDate)
    {
        // Salary (monthly, fixed amount)
        $salaryCategory = $categories->where('name', 'Salary')->first();
        if ($salaryCategory) {
            $salaryAmount = 85000; // Fixed salary of ₹85,000 to ensure consistent monthly income
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                // Salary credited on last day of month or first few days
                $salaryDate = clone $currentDate;
                $lastDay = $salaryDate->daysInMonth;
                $salaryDay = rand(0, 1) ? $lastDay : rand(1, 5);
                $salaryDate->setDay($salaryDay);
                
                if ($salaryDate >= $startDate && $salaryDate <= $endDate) {
                    // Add annual increment in April
                    if ($salaryDate->month == 4 && $salaryDate->year > $startDate->year) {
                        $salaryAmount *= (1 + (rand(10, 20) / 100)); // 10-20% increment (increased from 5-15%)
                    }
                    
                    // Add bonus in Diwali (October/November) and year-end (March)
                    $bonusAmount = 0;
                    $bonusDescription = '';
                    
                    if (in_array($salaryDate->month, [10, 11])) { // Diwali bonus
                        $bonusAmount = 30000; // Fixed Diwali bonus
                        $bonusDescription = 'Diwali bonus';
                    } elseif ($salaryDate->month == 3) { // Year-end bonus
                        $bonusAmount = 40000; // Fixed year-end bonus
                        $bonusDescription = 'Year-end bonus';
                    } else {
                        // Add monthly performance bonus to reach ~100,000 total monthly income
                        $bonusAmount = 15000; // Fixed monthly performance bonus
                        $bonusDescription = 'Monthly performance bonus';
                    }
                    
                    Transaction::create([
                        'user_id' => $user->id,
                        'category_id' => $salaryCategory->id,
                        'amount' => $salaryAmount,
                        'type' => 'income',
                        'date' => $salaryDate,
                        'description' => 'Monthly salary',
                    ]);
                    
                    // Always add a bonus (changed from conditional)
                    $bonusDate = clone $salaryDate;
                    $bonusDate->addDays(rand(0, 5));
                    
                    Transaction::create([
                        'user_id' => $user->id,
                        'category_id' => $salaryCategory->id,
                        'amount' => $bonusAmount,
                        'type' => 'income',
                        'date' => $bonusDate,
                        'description' => $bonusDescription,
                    ]);
                }
                $currentDate->addMonth();
            }
        }

        // Investments (quarterly or semi-annual returns)
        $investmentCategory = $categories->where('name', 'Investments')->first();
        if ($investmentCategory) {
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                // FD maturity (semi-annual)
                if ($currentDate->month % 6 == 0) {
                    $fdDate = clone $currentDate;
                    $fdDate->setDay(rand(10, 20));
                    
                    if ($fdDate >= $startDate && $fdDate <= $endDate) {
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $investmentCategory->id,
                            'amount' => rand(20000, 80000) + (rand(0, 99) / 100), // Increased from 10000-50000
                            'type' => 'income',
                            'date' => $fdDate,
                            'description' => 'Fixed Deposit maturity',
                        ]);
                    }
                }
                
                // Mutual fund returns (monthly instead of quarterly)
                $mfDate = clone $currentDate;
                $mfDate->setDay(rand(15, 25));
                
                if ($mfDate >= $startDate && $mfDate <= $endDate) {
                    Transaction::create([
                        'user_id' => $user->id,
                        'category_id' => $investmentCategory->id,
                        'amount' => rand(8000, 25000) + (rand(0, 99) / 100), // Increased from 5000-20000
                        'type' => 'income',
                        'date' => $mfDate,
                        'description' => 'Mutual Fund dividend',
                    ]);
                }
                
                // Stock dividends (more frequent - 50% chance each month)
                if (rand(1, 2) == 1) { // 50% chance each month (increased from 33%)
                    $stockDate = clone $currentDate;
                    $stockDate->setDay(rand(1, 28));
                    
                    if ($stockDate >= $startDate && $stockDate <= $endDate) {
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $investmentCategory->id,
                            'amount' => rand(3000, 10000) + (rand(0, 99) / 100), // Increased from 1000-5000
                            'type' => 'income',
                            'date' => $stockDate,
                            'description' => 'Stock dividend',
                        ]);
                    }
                }
                
                // Add rental income (new)
                $rentalDate = clone $currentDate;
                $rentalDate->setDay(rand(1, 5));
                
                if ($rentalDate >= $startDate && $rentalDate <= $endDate) {
                    Transaction::create([
                        'user_id' => $user->id,
                        'category_id' => $investmentCategory->id,
                        'amount' => rand(15000, 30000) + (rand(0, 99) / 100),
                        'type' => 'income',
                        'date' => $rentalDate,
                        'description' => 'Rental income',
                    ]);
                }
                
                $currentDate->addMonth();
            }
        }

        // Freelance (irregular income)
        $freelanceCategory = $categories->where('name', 'Freelance')->first();
        if ($freelanceCategory) {
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                // 0-3 freelance payments per month
                $monthlyFreelance = rand(0, 3);
                for ($i = 0; $i < $monthlyFreelance; $i++) {
                    $transactionDate = clone $currentDate;
                    $transactionDate->addDays(rand(0, 29));
                    
                    if ($transactionDate <= $endDate) {
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $freelanceCategory->id,
                            'amount' => rand(5000, 30000) + (rand(0, 99) / 100),
                            'type' => 'income',
                            'date' => $transactionDate,
                            'description' => $this->getRandomFreelanceDescription(),
                        ]);
                    }
                }
                $currentDate->addMonth();
            }
        }

        // Gifts (occasional, festival-related)
        $giftsCategory = $categories->where('name', 'Gifts')->first();
        if ($giftsCategory) {
            $currentDate = clone $startDate;
            while ($currentDate <= $endDate) {
                // Festival gifts (Diwali, Holi, etc.)
                $isFestivalMonth = in_array($currentDate->month, [3, 10, 11]); // Holi (March), Diwali (Oct/Nov)
                
                if ($isFestivalMonth) {
                    $festivalDate = clone $currentDate;
                    $festivalDate->setDay(rand(10, 20));
                    
                    if ($festivalDate >= $startDate && $festivalDate <= $endDate) {
                        $festival = $currentDate->month == 3 ? 'Holi' : 'Diwali';
                        
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $giftsCategory->id,
                            'amount' => rand(1000, 10000) + (rand(0, 99) / 100),
                            'type' => 'income',
                            'date' => $festivalDate,
                            'description' => $festival . ' gift',
                        ]);
                    }
                }
                
                // Birthday gifts (once a year)
                if ($currentDate->month == rand(1, 12)) {
                    $birthdayDate = clone $currentDate;
                    $birthdayDate->setDay(rand(1, 28));
                    
                    if ($birthdayDate >= $startDate && $birthdayDate <= $endDate) {
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $giftsCategory->id,
                            'amount' => rand(2000, 5000) + (rand(0, 99) / 100),
                            'type' => 'income',
                            'date' => $birthdayDate,
                            'description' => 'Birthday gift',
                        ]);
                    }
                }
                
                // Random gifts (occasional)
                if (rand(1, 6) == 1) { // 16.7% chance each month
                    $giftDate = clone $currentDate;
                    $giftDate->setDay(rand(1, 28));
                    
                    if ($giftDate >= $startDate && $giftDate <= $endDate) {
                        Transaction::create([
                            'user_id' => $user->id,
                            'category_id' => $giftsCategory->id,
                            'amount' => rand(500, 3000) + (rand(0, 99) / 100),
                            'type' => 'income',
                            'date' => $giftDate,
                            'description' => 'Gift from family/friend',
                        ]);
                    }
                }
                
                $currentDate->addMonth();
            }
        }
    }

    /**
     * Get a random grocery description
     */
    private function getRandomGroceryDescription()
    {
        $descriptions = [
            'Big Bazaar grocery shopping',
            'D-Mart weekly groceries',
            'Reliance Fresh vegetables and fruits',
            'Local kirana store items',
            'Nature\'s Basket premium groceries',
            'Monthly grocery stock-up',
            'Vegetables from local market',
            'Fruits and dairy products',
            'Household essentials',
            'Pantry restocking',
            'Spices and dry goods',
            'Milk and bread',
            'Snacks and beverages',
        ];
        
        return $descriptions[array_rand($descriptions)];
    }

    /**
     * Get a random dining description
     */
    private function getRandomDiningDescription()
    {
        $descriptions = [
            'Lunch at office canteen',
            'Dinner at Mainland China',
            'Pizza delivery from Domino\'s',
            'Swiggy food delivery',
            'Zomato order',
            'Breakfast at Cafe Coffee Day',
            'Dinner at Punjabi restaurant',
            'South Indian lunch at Saravana Bhavan',
            'Street food at local chaat corner',
            'Biryani from Paradise',
            'Chinese takeout',
            'Dinner with friends at Barbeque Nation',
            'Ice cream at Naturals',
            'Quick bite at McDonald\'s',
            'Lunch at office food court',
        ];
        
        return $descriptions[array_rand($descriptions)];
    }

    /**
     * Get a random OTT description
     */
    private function getRandomOTTDescription()
    {
        $descriptions = [
            'Netflix monthly subscription',
            'Amazon Prime annual renewal',
            'Disney+ Hotstar subscription',
            'SonyLIV premium plan',
            'ZEE5 subscription',
            'JioCinema premium',
            'Voot Select subscription',
            'Apple TV+ monthly plan',
        ];
        
        return $descriptions[array_rand($descriptions)];
    }

    /**
     * Get a random freelance description
     */
    private function getRandomFreelanceDescription()
    {
        $descriptions = [
            'Website development project',
            'Logo design for client',
            'Content writing assignment',
            'Social media management',
            'UI/UX design project',
            'Mobile app development',
            'Photography assignment',
            'Video editing project',
            'Translation work',
            'Online tutoring',
            'Consulting services',
            'Graphic design project',
        ];
        
        return $descriptions[array_rand($descriptions)];
    }
}