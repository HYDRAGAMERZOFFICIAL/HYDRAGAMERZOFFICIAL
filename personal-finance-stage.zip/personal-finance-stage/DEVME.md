# Personal Finance App

Step 1: Create Laravel Project
composer create-project laravel/laravel personal_finance

Run below command, it should display laravel home page
php artisan serve

Step 2: Installing react dependency
composer require laravel/breeze --dev

Step 3: Add react scaffolding
php artisan breeze:install react

step 4: Add models and migrations for Category, Transaction and Budget
php artisan make:model Category -m
php artisan make:model Transaction -m
php artisan make:model Budget -m

// for installing toast to show notification messages
npm install react-hot-toast 

// for create symbolic link of storage director in public directory
php artisan storage:link
