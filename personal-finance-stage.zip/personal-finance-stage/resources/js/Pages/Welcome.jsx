import { Head, Link } from '@inertiajs/react';
import { useState } from 'react';

export default function Welcome({ auth, laravelVersion, phpVersion }) {
    const [showUserGuide, setShowUserGuide] = useState(false);
    return (
        <>
            <Head title="PERA FIN CORE - Personal Finance Management" />
            <div className="relative min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-indigo-950 selection:bg-blue-500 selection:text-white">
                {/* User Guide Button */}
                <button 
                    className="fixed top-20 right-5 z-50 px-6 py-3 bg-orange-500 text-white rounded-full shadow-lg hover:bg-orange-600 transition duration-300 flex items-center"
                    onClick={() => setShowUserGuide(true)}
                >
                    <i className="fas fa-lightbulb mr-2"></i> User Guide
                </button>
                
                {/* User Guide Modal */}
                {showUserGuide && (
                    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[1000] animate-fadeIn">
                        <div 
                            className="bg-indigo-900 bg-opacity-75 rounded-xl w-11/12 max-w-4xl max-h-[90vh] p-8 text-white overflow-y-auto transform translate-y-0 animate-slideUp relative"
                            style={{ boxShadow: '0 10px 30px rgba(0, 0, 0, 0.2)' }}
                        >
                            <button 
                                className="absolute top-4 right-4 bg-red-500 text-white w-10 h-10 rounded-full flex items-center justify-center text-xl hover:bg-red-600 transition duration-300"
                                onClick={() => setShowUserGuide(false)}
                            >
                                ×
                            </button>
                            
                            <h1 className="text-3xl font-bold mb-6 text-center">User Guide</h1>
                            
                            <div className="space-y-6">
                                <div>
                                    <h2 className="text-xl font-semibold mb-3 text-yellow-300 border-l-4 border-orange-500 pl-3">1. Registration</h2>
                                    <ul className="list-disc pl-6 space-y-2">
                                        <li>Click on <strong>Get Started</strong> or <strong>Register</strong>.</li>
                                        <li>Enter a valid <strong>name</strong>, <strong>email</strong>, and <strong>phone number</strong>.</li>
                                        <li>Password must include uppercase, lowercase, symbol, number, and be over 6 characters.</li>
                                        <li>Click <strong>Sign Up</strong> and verify via email.</li>
                                        <li>After verification, you will be logged into the dashboard.</li>
                                    </ul>
                                </div>
                                
                                <div>
                                    <h2 className="text-xl font-semibold mb-3 text-yellow-300 border-l-4 border-orange-500 pl-3">2. Login & Authentication</h2>
                                    <ul className="list-disc pl-6 space-y-2">
                                        <li>Login with email and password.</li>
                                        <li>If 2FA is active, use Google Authenticator for the code.</li>
                                    </ul>
                                </div>
                                
                                <div>
                                    <h2 className="text-xl font-semibold mb-3 text-yellow-300 border-l-4 border-orange-500 pl-3">3. Dashboard Overview</h2>
                                    <ul className="list-disc pl-6 space-y-2">
                                        <li>Shows income, expenses, and remaining balance for the month.</li>
                                        <li>Displays transactions and categories.</li>
                                        <li>Navigation tabs: Categories, Transactions, Budget, Report.</li>
                                    </ul>
                                    
                                    <div className="mt-4 ml-4">
                                        <h3 className="text-lg font-semibold mb-2 text-yellow-200">3.1 Categories</h3>
                                        <ul className="list-disc pl-6 space-y-2">
                                            <li>Click <strong>Add Category</strong>.</li>
                                            <li>Set name, type (Income/Expense), color, and description.</li>
                                            <li>Click <strong>Save</strong>.</li>
                                        </ul>
                                    </div>
                                    
                                    <div className="mt-4 ml-4">
                                        <h3 className="text-lg font-semibold mb-2 text-yellow-200">3.2 Transactions</h3>
                                        <ul className="list-disc pl-6 space-y-2">
                                            <li>Click <strong>Add Transaction</strong>.</li>
                                            <li>Choose category, enter amount, description, and optionally attach bill.</li>
                                            <li>Click <strong>Save</strong>.</li>
                                        </ul>
                                    </div>
                                    
                                    <div className="mt-4 ml-4">
                                        <h3 className="text-lg font-semibold mb-2 text-yellow-200">3.3 Budget</h3>
                                        <ul className="list-disc pl-6 space-y-2">
                                            <li>Click <strong>Add Budget</strong>.</li>
                                            <li>Select category, enter amount, and choose duration.</li>
                                            <li>Click <strong>Save</strong>.</li>
                                        </ul>
                                    </div>
                                    
                                    <div className="mt-4 ml-4">
                                        <h3 className="text-lg font-semibold mb-2 text-yellow-200">3.4 Report</h3>
                                        <ul className="list-disc pl-6 space-y-2">
                                            <li>View income/expense reports categorized by date.</li>
                                            <li>Use <strong>Custom Range</strong> to filter.</li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <div>
                                    <h2 className="text-xl font-semibold mb-3 text-yellow-300 border-l-4 border-orange-500 pl-3">4. Two-Factor Authentication (2FA)</h2>
                                    <ul className="list-disc pl-6 space-y-2">
                                        <li>Install <strong>Google Authenticator</strong>.</li>
                                        <li>Go to Profile in dashboard.</li>
                                        <li>Click <strong>Enable 2FA</strong> and scan the QR code.</li>
                                        <li>Enter the code from the app and click <strong>Submit</strong>.</li>
                                        <li>Re-enter to confirm and activate 2FA.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                {/* Navigation */}
                <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md shadow-sm">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className="flex justify-between h-16">
                            <div className="flex items-center">
                                <div className="flex-shrink-0 flex items-center">
                                    <img
                                        src="/images/pfc_logo.png"
                                        alt="Pera Fin Core"
                                        className="w-10 h-10"
                                    />
                                    <span className="ml-2 text-xl font-bold text-gray-900 dark:text-white">PERA FIN CORE</span>
                                </div>
                            </div>
                            <div className="flex items-center">
                                {auth.user ? (
                                    <Link
                                        href={route('dashboard')}
                                        className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                            <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
                                        </svg>
                                        Dashboard
                                    </Link>
                                ) : (
                                    <>
                                        <Link
                                            href={route('login')}
                                            className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-700 text-sm font-medium rounded-md text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out"
                                        >
                                            Log in
                                        </Link>

                                        <Link
                                            href={route('register')}
                                            className="ml-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out"
                                        >
                                            Register
                                        </Link>
                                    </>
                                )}
                            </div>
                        </div>
                    </div>
                </nav>

                {/* Hero Section */}
                <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
                    <div className="max-w-7xl mx-auto">
                        <div className="text-center">
                            <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 dark:text-white sm:text-5xl md:text-6xl">
                                <span className="block">Take Control of Your</span>
                                <span className="block text-blue-600 dark:text-blue-400">Financial Future</span>
                            </h1>
                            <p className="mt-3 max-w-md mx-auto text-base text-gray-500 dark:text-gray-300 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
                                Track expenses, manage budgets, and achieve your financial goals with our intuitive personal finance management tools.
                            </p>
                            <div className="mt-10 flex justify-center">
                                <div className="rounded-md shadow">
                                    <Link
                                        href={route('register')}
                                        className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10 transition duration-150 ease-in-out"
                                    >
                                        Get Started
                                    </Link>
                                </div>
                                <div className="ml-3 rounded-md shadow">
                                    <a
                                        href="#features"
                                        className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-blue-600 bg-white hover:bg-gray-50 dark:text-blue-400 dark:bg-gray-800 dark:hover:bg-gray-700 md:py-4 md:text-lg md:px-10 transition duration-150 ease-in-out"
                                    >
                                        Learn More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Features Section */}
                <div id="features" className="py-16 bg-white dark:bg-gray-800 overflow-hidden">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className="text-center">
                            <h2 className="text-base font-semibold text-blue-600 dark:text-blue-400 tracking-wide uppercase">Features</h2>
                            <p className="mt-2 text-3xl font-extrabold text-gray-900 dark:text-white tracking-tight sm:text-4xl">
                                Everything you need to manage your finances
                            </p>
                            <p className="mt-5 max-w-prose mx-auto text-xl text-gray-500 dark:text-gray-300">
                                Our comprehensive suite of tools helps you stay on top of your financial health
                            </p>
                        </div>

                        <div className="mt-12">
                            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
                                {/* Feature 1 */}
                                <div className="pt-6">
                                    <div className="flow-root bg-gray-50 dark:bg-gray-900 rounded-lg px-6 pb-8">
                                        <div className="-mt-6">
                                            <div>
                                                <span className="inline-flex items-center justify-center p-3 bg-blue-500 rounded-md shadow-lg">
                                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                                                    </svg>
                                                </span>
                                            </div>
                                            <h3 className="mt-8 text-lg font-medium text-gray-900 dark:text-white tracking-tight">Expense Tracking</h3>
                                            <p className="mt-5 text-base text-gray-500 dark:text-gray-400">
                                                Easily log and categorize your expenses. Get insights into your spending habits with detailed reports and visualizations.
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                {/* Feature 2 */}
                                <div className="pt-6">
                                    <div className="flow-root bg-gray-50 dark:bg-gray-900 rounded-lg px-6 pb-8">
                                        <div className="-mt-6">
                                            <div>
                                                <span className="inline-flex items-center justify-center p-3 bg-blue-500 rounded-md shadow-lg">
                                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                    </svg>
                                                </span>
                                            </div>
                                            <h3 className="mt-8 text-lg font-medium text-gray-900 dark:text-white tracking-tight">Budget Management</h3>
                                            <p className="mt-5 text-base text-gray-500 dark:text-gray-400">
                                                Create personalized budgets for different categories. Receive alerts when you're approaching your spending limits.
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                {/* Feature 3 */}
                                <div className="pt-6">
                                    <div className="flow-root bg-gray-50 dark:bg-gray-900 rounded-lg px-6 pb-8">
                                        <div className="-mt-6">
                                            <div>
                                                <span className="inline-flex items-center justify-center p-3 bg-blue-500 rounded-md shadow-lg">
                                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                                    </svg>
                                                </span>
                                            </div>
                                            <h3 className="mt-8 text-lg font-medium text-gray-900 dark:text-white tracking-tight">Financial Analytics</h3>
                                            <p className="mt-5 text-base text-gray-500 dark:text-gray-400">
                                                Gain valuable insights with interactive charts and reports. Understand your financial trends and make informed decisions.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Testimonials */}
                <div className="bg-blue-50 dark:bg-gray-900 py-16">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className="text-center">
                            <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white">
                                Trusted by users worldwide
                            </h2>
                            <p className="mt-4 text-lg text-gray-500 dark:text-gray-300">
                                See how PERA FIN CORE has helped people take control of their finances
                            </p>
                        </div>
                        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
                                <div className="px-6 py-8">
                                    <div className="flex items-center">
                                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                            <span className="text-blue-600 font-bold">JD</span>
                                        </div>
                                        <div className="ml-4">
                                            <h3 className="text-lg font-medium text-gray-900 dark:text-white">John Doe</h3>
                                            <p className="text-sm text-gray-500 dark:text-gray-400">Small Business Owner</p>
                                        </div>
                                    </div>
                                    <p className="mt-4 text-gray-600 dark:text-gray-300">
                                        "PERA FIN CORE has completely transformed how I manage both my personal and business finances. The insights are invaluable."
                                    </p>
                                </div>
                            </div>
                            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
                                <div className="px-6 py-8">
                                    <div className="flex items-center">
                                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                            <span className="text-blue-600 font-bold">AS</span>
                                        </div>
                                        <div className="ml-4">
                                            <h3 className="text-lg font-medium text-gray-900 dark:text-white">Amanda Smith</h3>
                                            <p className="text-sm text-gray-500 dark:text-gray-400">Freelancer</p>
                                        </div>
                                    </div>
                                    <p className="mt-4 text-gray-600 dark:text-gray-300">
                                        "As a freelancer, tracking income and expenses was always a challenge. PERA FIN CORE makes it simple and intuitive."
                                    </p>
                                </div>
                            </div>
                            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden md:col-span-2 lg:col-span-1">
                                <div className="px-6 py-8">
                                    <div className="flex items-center">
                                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                            <span className="text-blue-600 font-bold">RJ</span>
                                        </div>
                                        <div className="ml-4">
                                            <h3 className="text-lg font-medium text-gray-900 dark:text-white">Robert Johnson</h3>
                                            <p className="text-sm text-gray-500 dark:text-gray-400">Student</p>
                                        </div>
                                    </div>
                                    <p className="mt-4 text-gray-600 dark:text-gray-300">
                                        "The budgeting features helped me save for my education while keeping track of daily expenses. Highly recommended!"
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* CTA Section */}
                <div className="bg-blue-600 dark:bg-blue-800">
                    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8 lg:flex lg:items-center lg:justify-between">
                        <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
                            <span className="block">Ready to take control?</span>
                            <span className="block text-blue-200">Start your financial journey today.</span>
                        </h2>
                        <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
                            <div className="inline-flex rounded-md shadow">
                                <Link
                                    href={route('register')}
                                    className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-blue-600 bg-white hover:bg-blue-50 transition duration-150 ease-in-out"
                                >
                                    Get started
                                </Link>
                            </div>
                            <div className="ml-3 inline-flex rounded-md shadow">
                                <Link
                                    href={route('login')}
                                    className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-800 hover:bg-blue-700 transition duration-150 ease-in-out"
                                >
                                    Log in
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div className="bg-blue-50 dark:bg-gray-900 py-4">
                    <div className="max-w-7xl mx-auto py-1 px-2 sm:px-1 lg:py-0 lg:px-8 lg:flex lg:items-center lg:justify-between">
                        <h2 className="text-sm font-extrabold tracking-tight text-white sm:text-lg">
                            <span className="block">Need Help?</span>
                            <span className="block text-blue-200">
                                If you have any questions or need assistance, please contact our support team at - {' '}
                                <a href="mailto:perafincore@gmail.com" className="underline text-blue-400">
                                    perafincore@gmail.com
                                </a>
                            </span>
                        </h2>
                    </div>
                </div>

                {/* Footer */}
                <footer className="bg-white dark:bg-gray-900">
                    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 md:flex md:items-center md:justify-between lg:px-8">
                        <div className="flex justify-center space-x-6 md:order-2">
                            <a href="https://www.facebook.com/profile.php?id=61576289824587" className="text-gray-400 hover:text-gray-500">
                                <span className="sr-only">Facebook</span>
                                <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                    <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
                                </svg>
                            </a>
                            <a href="https://www.instagram.com/pera_fin_core/" className="text-gray-400 hover:text-gray-500">
                                <span className="sr-only">Instagram</span>
                                <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                    <path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" clipRule="evenodd" />
                                </svg>
                            </a>
                            <a href="https://x.com/Pera_Fin_Code" className="text-gray-400 hover:text-gray-500">
                                <span className="sr-only">Twitter</span>
                                <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                                </svg>
                            </a>
                        </div>
                        <div className="mt-8 md:mt-0 md:order-1">
                            <p className="text-center text-base text-gray-400">
                                &copy; {new Date().getFullYear()} PERA FIN CORE Finance. All rights reserved.
                            </p>
                        </div>
                    </div>
                </footer>
            </div>
        </>
    );
}
