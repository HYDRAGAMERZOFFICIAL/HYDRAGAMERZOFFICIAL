import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, Link } from '@inertiajs/react';
import { useState, useEffect } from 'react';
import { formatCurrency } from '@/utils';

export default function Dashboard({ 
    auth, 
    recentTransactions, 
    filteredTransactions,
    periodIncome, 
    periodExpense, 
    periodSavings, 
    savingsRate, 
    categoryTotals, 
    dateRange,
    goalStats,
    upcomingGoals,
    budgetStats,
    topBudgets
}) {
    const [showDateFilter, setShowDateFilter] = useState(false);
    const [transactionType, setTransactionType] = useState('all'); // 'all', 'income', or 'expense'
    
    const { data, setData, get, processing } = useForm({
        start_date: dateRange.start_date || '',
        end_date: dateRange.end_date || ''
    });
    
    // Reset end date if start date is after end date
    useEffect(() => {
        if (data.start_date && data.end_date) {
            const startDate = new Date(data.start_date);
            const endDate = new Date(data.end_date);
            
            if (startDate > endDate) {
                // Set end date to start date or later (we'll use start date + 1 month)
                const newEndDate = new Date(startDate);
                newEndDate.setMonth(startDate.getMonth() + 1);
                newEndDate.setDate(0); // Last day of the month
                
                setData('end_date', newEndDate.toISOString().split('T')[0]);
            }
        }
    }, [data.start_date]);
    
    const handleDateFilterSubmit = (e) => {
        e.preventDefault();
        get(route('dashboard'), {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => {
                setShowDateFilter(false);
            }
        });
    };
    
    // Format date for display
    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    };
    
    // Reset to current month
    const resetToCurrentMonth = () => {
        const today = new Date();
        // Set to 1st day of current month
        const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        // Set to last day of current month (0th day of next month = last day of current month)
        const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        
        setData({
            start_date: startOfMonth.toISOString().split('T')[0],
            end_date: endOfMonth.toISOString().split('T')[0]
        });
        
        get(route('dashboard'), {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => {
                setShowDateFilter(false);
            }
        });
    };
    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Dashboard</h2>}
        >
            <Head title="Dashboard" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    {/* Date Filter */}
                    <div className="mb-6 flex justify-between items-center">
                        <div className="flex items-center">
                            <h3 className="text-lg font-semibold mr-4">
                                {formatDate(dateRange.start_date)} - {formatDate(dateRange.end_date)}
                            </h3>
                            <button
                                onClick={() => setShowDateFilter(!showDateFilter)}
                                className="bg-gray-200 text-gray-700 px-3 py-1 rounded-lg hover:bg-gray-300 text-sm"
                            >
                                {showDateFilter ? 'Hide Filter' : 'Change Date Range'}
                            </button>
                        </div>
                        <button
                            onClick={resetToCurrentMonth}
                            className="text-blue-500 hover:text-blue-700 text-sm"
                        >
                            Reset to Current Month
                        </button>
                    </div>
                    
                    {/* Date Range Filter Form */}
                    {showDateFilter && (
                        <div className="mb-6 bg-white p-4 rounded-lg shadow">
                            <h3 className="text-md font-semibold mb-3">Select Date Range</h3>
                            <form onSubmit={handleDateFilterSubmit}>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">
                                            Start Date
                                        </label>
                                        <input
                                            type="date"
                                            value={data.start_date}
                                            onChange={e => {
                                                const newStartDate = e.target.value;
                                                setData('start_date', newStartDate);
                                                
                                                // If end date is empty, set it to the end of the month of the start date
                                                if (!data.end_date) {
                                                    const startDate = new Date(newStartDate);
                                                    const endOfMonth = new Date(startDate.getFullYear(), startDate.getMonth() + 1, 0);
                                                    setData('end_date', endOfMonth.toISOString().split('T')[0]);
                                                }
                                            }}
                                            className="w-full border-gray-300 rounded-md shadow-sm"
                                            required
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">
                                            End Date
                                        </label>
                                        <input
                                            type="date"
                                            value={data.end_date}
                                            min={data.start_date} // Prevent selecting dates before start date
                                            onChange={e => setData('end_date', e.target.value)}
                                            className="w-full border-gray-300 rounded-md shadow-sm"
                                            required
                                        />
                                    </div>
                                </div>
                                <div className="flex justify-end">
                                    <button
                                        type="button"
                                        onClick={() => setShowDateFilter(false)}
                                        className="mr-2 bg-gray-300 text-gray-700 px-4 py-2 rounded"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        type="submit"
                                        disabled={processing || !data.start_date || !data.end_date}
                                        className="bg-blue-500 text-white px-4 py-2 rounded disabled:opacity-50"
                                    >
                                        Apply
                                    </button>
                                </div>
                            </form>
                        </div>
                    )}
                    
                    {/* Summary Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                            <h3 className="text-lg font-semibold mb-2">Income</h3>
                            <p className="text-3xl font-bold text-green-600">{formatCurrency(periodIncome)}</p>
                        </div>
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                            <h3 className="text-lg font-semibold mb-2">Expenses</h3>
                            <p className="text-3xl font-bold text-red-600">{formatCurrency(periodExpense)}</p>
                        </div>
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                            <h3 className="text-lg font-semibold mb-2">Balance</h3>
                            <p className="text-3xl font-bold text-blue-600">{formatCurrency(periodSavings)}</p>
                            <p className="text-sm text-gray-500 mt-1">Savings Rate: {savingsRate}%</p>
                        </div>
                    </div>

                    {/* Recent Transactions */}
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 mb-6">
                        <h3 className="text-lg font-semibold mb-4">Recent Transactions</h3>
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead>
                                    <tr>
                                        <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                        <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                        <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                        <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {recentTransactions.map((transaction) => (
                                        <tr key={transaction.id}>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{transaction.date}</td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{transaction.category.name}</td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                <span className={`px-2 py-1 rounded-full text-xs ${transaction.type === 'income' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                    {transaction.type}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{formatCurrency(transaction.amount)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    {/* Filtered Transactions Data Table */}
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 mb-6">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-semibold">Filtered Transactions</h3>
                            <div className="flex space-x-2">
                                <button 
                                    onClick={() => setTransactionType('all')}
                                    className={`px-3 py-1 rounded-lg text-sm ${
                                        transactionType === 'all' 
                                            ? 'bg-blue-500 text-white' 
                                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                    }`}
                                >
                                    All
                                </button>
                                <button 
                                    onClick={() => setTransactionType('income')}
                                    className={`px-3 py-1 rounded-lg text-sm ${
                                        transactionType === 'income' 
                                            ? 'bg-green-500 text-white' 
                                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                    }`}
                                >
                                    Income
                                </button>
                                <button 
                                    onClick={() => setTransactionType('expense')}
                                    className={`px-3 py-1 rounded-lg text-sm ${
                                        transactionType === 'expense' 
                                            ? 'bg-red-500 text-white' 
                                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                    }`}
                                >
                                    Expense
                                </button>
                            </div>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead>
                                    <tr>
                                        <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                        <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                                        <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                        <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                        <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {filteredTransactions
                                        .filter(transaction => 
                                            transactionType === 'all' || transaction.type === transactionType
                                        )
                                        .map((transaction) => (
                                            <tr key={transaction.id}>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                    {new Date(transaction.date).toLocaleDateString('en-IN', {
                                                        year: 'numeric',
                                                        month: 'short',
                                                        day: 'numeric'
                                                    })}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                    {transaction.description || '-'}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                    {transaction.category.name}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                    <span className={`px-2 py-1 rounded-full text-xs ${
                                                        transaction.type === 'income' 
                                                            ? 'bg-green-100 text-green-800' 
                                                            : 'bg-red-100 text-red-800'
                                                    }`}>
                                                        {transaction.type}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                    {formatCurrency(transaction.amount)}
                                                </td>
                                            </tr>
                                        ))
                                    }
                                    {filteredTransactions.filter(t => transactionType === 'all' || t.type === transactionType).length === 0 && (
                                        <tr>
                                            <td colSpan="5" className="px-6 py-4 text-center text-sm text-gray-500">
                                                No transactions found for the selected filter.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {/* Financial Goals */}
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 mb-6">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-semibold">Financial Goals</h3>
                            <Link href={route('goals.index')} className="text-indigo-600 hover:text-indigo-900 text-sm">
                                View All Goals
                            </Link>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <div className="p-4 border rounded-lg bg-gray-50">
                                <h4 className="font-medium text-gray-700">Active Goals</h4>
                                <p className="text-2xl font-semibold mt-2">{goalStats.activeGoals}</p>
                            </div>
                            <div className="p-4 border rounded-lg bg-gray-50">
                                <h4 className="font-medium text-gray-700">Completed Goals</h4>
                                <p className="text-2xl font-semibold mt-2">{goalStats.completedGoals}</p>
                            </div>
                            <div className="p-4 border rounded-lg bg-gray-50">
                                <h4 className="font-medium text-gray-700">Total Goals</h4>
                                <p className="text-2xl font-semibold mt-2">{goalStats.totalGoals}</p>
                            </div>
                        </div>
                        
                        {upcomingGoals && upcomingGoals.length > 0 && (
                            <div>
                                <h4 className="font-medium text-gray-700 mb-3">Upcoming Goals</h4>
                                <div className="overflow-x-auto">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead>
                                            <tr>
                                                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Target Date</th>
                                                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Progress</th>
                                                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-200">
                                            {upcomingGoals.map((goal) => {
                                                return (
                                                    <tr key={goal.id}>
                                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                            <Link href={route('goals.show', goal.id)} className="text-indigo-600 hover:text-indigo-900">
                                                                {goal.name}
                                                            </Link>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                            {new Date(goal.target_date).toLocaleDateString()}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                                                                <div 
                                                                    className="bg-indigo-600 h-2.5 rounded-full" 
                                                                    style={{ width: `${goal.progress_percentage}%` }}
                                                                ></div>
                                                            </div>
                                                            <span className="text-xs text-gray-500 mt-1">{goal.progress_percentage}%</span>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                            {formatCurrency(goal.target_amount)}
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Category Totals */}
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                        <h3 className="text-lg font-semibold mb-4">Category Totals</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {categoryTotals.map((category) => (
                                <div key={category.category_id} className="p-4 border rounded-lg">
                                    <div className="flex justify-between items-center">
                                        <h4 className="font-medium text-gray-700">{category.category.name}</h4>
                                        <span className={`px-2 py-1 rounded-full text-xs ${category.type === 'income' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                            {category.type}
                                        </span>
                                    </div>
                                    <p className="text-2xl font-semibold mt-2">{formatCurrency(category.total)}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
