import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head } from '@inertiajs/react';

export default function UserGuide({ auth }) {
    const openCompactGmailPopup = () => {
        const url = 'https://mail.google.com/mail/?view=cm&fs=1&to=perafincore@gmail.com';
        const width = 800;
        const height = 600;
        const left = (window.screen.width - width) / 2;
        const top = (window.screen.height - height) / 2;

        window.open(
            url,
            'gmailCompose',
            `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes`
        );
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">User Guide</h2>}
        >
            <Head title="User Guide" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900 space-y-6">
                            <section className="animate-fadeIn">
                                <h3 className="text-lg font-medium text-gray-900 mb-2">Welcome to PERA FIN CORE - Your Personal Finance Manager</h3>
                                <p className="text-gray-600">
                                    This guide will help you navigate through the features and functionalities of PERA FIN CORE.
                                </p>
                            </section>

                            <section className="animate-slideUp" style={{ animationDelay: '0.1s' }}>
                                <h3 className="text-lg font-medium text-gray-900 mb-2">Dashboard</h3>
                                <p className="text-gray-600 mb-2">
                                    The dashboard provides an overview of your financial status, including:
                                </p>
                                <ul className="list-disc pl-5 text-gray-600">
                                    <li>Total income and expenses</li>
                                    <li>Recent transactions</li>
                                    <li>Budget summaries</li>
                                    <li>Financial goals progress</li>
                                </ul>
                            </section>

                            <section className="animate-slideUp" style={{ animationDelay: '0.2s' }}>
                                <h3 className="text-lg font-medium text-gray-900 mb-2">Categories</h3>
                                <p className="text-gray-600 mb-2">
                                    Categories help you organize your transactions:
                                </p>
                                <ul className="list-disc pl-5 text-gray-600">
                                    <li>Create custom categories for income and expenses</li>
                                    <li>Edit or delete existing categories</li>
                                    <li>View transactions associated with each category</li>
                                </ul>
                            </section>

                            <section className="animate-slideUp" style={{ animationDelay: '0.3s' }}>
                                <h3 className="text-lg font-medium text-gray-900 mb-2">Transactions</h3>
                                <p className="text-gray-600 mb-2">
                                    Record and manage your financial transactions:
                                </p>
                                <ul className="list-disc pl-5 text-gray-600">
                                    <li>Add new income or expense transactions</li>
                                    <li>Categorize transactions</li>
                                    <li>Filter and search transactions</li>
                                    <li>Edit or delete existing transactions</li>
                                </ul>
                            </section>

                            <section className="animate-slideUp" style={{ animationDelay: '0.4s' }}>
                                <h3 className="text-lg font-medium text-gray-900 mb-2">Budgets</h3>
                                <p className="text-gray-600 mb-2">
                                    Create and manage budgets to control your spending:
                                </p>
                                <ul className="list-disc pl-5 text-gray-600">
                                    <li>Set budget limits for different categories</li>
                                    <li>Track your spending against budgets</li>
                                    <li>View budget analytics and summaries</li>
                                </ul>
                            </section>

                            <section className="animate-slideUp" style={{ animationDelay: '0.5s' }}>
                                <h3 className="text-lg font-medium text-gray-900 mb-2">Goals</h3>
                                <p className="text-gray-600 mb-2">
                                    Set and track financial goals:
                                </p>
                                <ul className="list-disc pl-5 text-gray-600">
                                    <li>Create savings goals with target amounts and dates</li>
                                    <li>Track progress towards your goals</li>
                                    <li>Update goal progress as you save</li>
                                </ul>
                            </section>

                            <section className="animate-slideUp" style={{ animationDelay: '0.6s' }}>
                                <h3 className="text-lg font-medium text-gray-900 mb-2">Reports</h3>
                                <p className="text-gray-600 mb-2">
                                    Generate financial reports to gain insights:
                                </p>
                                <ul className="list-disc pl-5 text-gray-600">
                                    <li>Category analysis to see where your money goes</li>
                                    <li>Income vs. expense comparisons</li>
                                    <li>Trend analysis over time</li>
                                </ul>
                            </section>

                            <section className="animate-slideUp" style={{ animationDelay: '0.7s' }}>
                                <h3 className="text-lg font-medium text-gray-900 mb-2">Profile Management</h3>
                                <p className="text-gray-600 mb-2">
                                    Manage your account settings:
                                </p>
                                <ul className="list-disc pl-5 text-gray-600">
                                    <li>Update personal information</li>
                                    <li>Change password</li>
                                    <li>Enable/disable two-factor authentication</li>
                                </ul>
                            </section>

                            <section className="animate-slideUp" style={{ animationDelay: '0.8s' }}>
                                <h3 className="text-lg font-medium text-gray-900 mb-2">Need Help?</h3>
                                <p className="text-gray-600">
                                    If you have any questions or need assistance, please contact our support team at -{' '}
                                    <span
                                        className="text-blue-200 underline cursor-pointer"
                                        onClick={openCompactGmailPopup}
                                    >
                                        perafincore@gmail.com
                                    </span>
                                </p>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}