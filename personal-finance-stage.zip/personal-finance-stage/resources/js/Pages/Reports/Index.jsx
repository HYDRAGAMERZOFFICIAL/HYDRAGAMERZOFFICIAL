import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm, router } from '@inertiajs/react';
import { useState, useEffect } from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title } from 'chart.js';
import { Pie, Line, Bar } from 'react-chartjs-2';

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title);

export default function ReportsIndex({ auth, filters, summary, categoryBreakdown, trends, topExpenseCategories, topIncomeCategories }) {
    const [activeTab, setActiveTab] = useState('overview');
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [chartData, setChartData] = useState({
        labels: [],
        income: [],
        expense: []
    });
    
    // Update chart data when trends prop changes
    useEffect(() => {
        console.log('Trends data updated:', trends);
        if (trends && trends.labels && trends.income && trends.expense) {
            setChartData({
                labels: trends.labels,
                income: trends.income,
                expense: trends.expense
            });
            console.log('Chart data set to:', {
                labels: trends.labels,
                income: trends.income,
                expense: trends.expense
            });
        }
    }, [trends]);
    
    const { data, setData, get, processing } = useForm({
        start_date: filters.start_date || '',
        end_date: filters.end_date || '',
        period: filters.period || 'month'
    });
    
    // Prepare data for pie charts
    const expenseCategories = categoryBreakdown.filter(item => item.type === 'expense');
    const incomeCategories = categoryBreakdown.filter(item => item.type === 'income');
    
    const expensePieData = {
        labels: expenseCategories.map(cat => cat.category_name),
        datasets: [
            {
                data: expenseCategories.map(cat => cat.total),
                backgroundColor: expenseCategories.map(cat => cat.category_color),
                borderWidth: 1,
            },
        ],
    };
    
    const incomePieData = {
        labels: incomeCategories.map(cat => cat.category_name),
        datasets: [
            {
                data: incomeCategories.map(cat => cat.total),
                backgroundColor: incomeCategories.map(cat => cat.category_color),
                borderWidth: 1,
            },
        ],
    };
    
    // Prepare data for trend line chart
    // Use the chartData state which is updated via useEffect when trends prop changes
    const trendData = {
        labels: chartData.labels,
        datasets: [
            {
                label: 'Income',
                data: chartData.income,
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.5)',
                tension: 0.1,
            },
            {
                label: 'Expense',
                data: chartData.expense,
                borderColor: 'rgb(255, 99, 132)',
                backgroundColor: 'rgba(255, 99, 132, 0.5)',
                tension: 0.1,
            },
        ],
    };
    
    // Log the current trend data for debugging
    console.log('Current trend data:', trendData);
    
    // Format currency
    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 0
        }).format(amount);
    };
    
    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Financial Reports</h2>}
        >
            <Head title="Financial Reports" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    {/* Filter Controls */}
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 mb-6">
                        <h3 className="text-lg font-semibold mb-4">Report Period</h3>
                        <div className="flex flex-wrap gap-2 mb-3">
                            <Link
                                href={route('reports.index', { period: 'week' })}
                                className={`px-4 py-2 rounded-lg ${filters.period === 'week' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
                            >
                                This Week
                            </Link>
                            <Link
                                href={route('reports.index', { period: 'month' })}
                                className={`px-4 py-2 rounded-lg ${filters.period === 'month' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
                            >
                                This Month
                            </Link>
                            <Link
                                href={route('reports.index', { period: 'quarter' })}
                                className={`px-4 py-2 rounded-lg ${filters.period === 'quarter' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
                            >
                                This Quarter
                            </Link>
                            <Link
                                href={route('reports.index', { period: 'year' })}
                                className={`px-4 py-2 rounded-lg ${filters.period === 'year' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
                            >
                                This Year
                            </Link>
                            <button
                                type="button"
                                onClick={() => setShowDatePicker(!showDatePicker)}
                                className={`px-4 py-2 rounded-lg ${filters.period === 'custom' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
                            >
                                Custom Range
                            </button>
                        </div>
                        
                        {/* Custom Date Range Picker */}
                        {showDatePicker && (
                            <div className="bg-gray-50 p-4 rounded-lg border mb-4">
                                <h4 className="font-medium mb-3">Select Custom Date Range</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">
                                            Start Date
                                        </label>
                                        <input
                                            type="date"
                                            value={data.start_date}
                                            onChange={e => setData('start_date', e.target.value)}
                                            className="w-full border-gray-300 rounded-md shadow-sm"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">
                                            End Date
                                        </label>
                                        <input
                                            type="date"
                                            value={data.end_date}
                                            onChange={e => setData('end_date', e.target.value)}
                                            className="w-full border-gray-300 rounded-md shadow-sm"
                                        />
                                    </div>
                                </div>
                                <div className="flex justify-end">
                                    <Link
                                        href={route('reports.index', {
                                            period: 'custom',
                                            start_date: data.start_date,
                                            end_date: data.end_date
                                        })}
                                        className={`px-4 py-2 rounded-md ${!data.start_date || !data.end_date ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-blue-500 text-white'}`}
                                        onClick={(e) => {
                                            if (!data.start_date || !data.end_date) {
                                                e.preventDefault();
                                            }
                                        }}
                                    >
                                        Apply Date Range
                                    </Link>
                                </div>
                            </div>
                        )}
                        
                        {/* Current Period Display */}
                        <div className="text-sm text-gray-600">
                            {filters.period === 'custom' ? (
                                <span>Showing data from {new Date(filters.start_date).toLocaleDateString()} to {new Date(filters.end_date).toLocaleDateString()}</span>
                            ) : (
                                <span>Showing data for {filters.period === 'week' ? 'this week' : 
                                                        filters.period === 'month' ? 'this month' : 
                                                        filters.period === 'quarter' ? 'this quarter' : 'this year'}</span>
                            )}
                        </div>
                    </div>
                    
                    {/* Report Navigation Tabs */}
                    <div className="mb-6 border-b border-gray-200">
                        <ul className="flex flex-wrap -mb-px text-sm font-medium text-center">
                            <li className="mr-2">
                                <button
                                    className={`inline-block p-4 border-b-2 rounded-t-lg ${activeTab === 'overview' ? 'border-blue-500 text-blue-600' : 'border-transparent hover:text-gray-600 hover:border-gray-300'}`}
                                    onClick={() => setActiveTab('overview')}
                                >
                                    Overview
                                </button>
                            </li>
                            <li className="mr-2">
                                <button
                                    className={`inline-block p-4 border-b-2 rounded-t-lg ${activeTab === 'expenses' ? 'border-blue-500 text-blue-600' : 'border-transparent hover:text-gray-600 hover:border-gray-300'}`}
                                    onClick={() => setActiveTab('expenses')}
                                >
                                    Expenses
                                </button>
                            </li>
                            <li className="mr-2">
                                <button
                                    className={`inline-block p-4 border-b-2 rounded-t-lg ${activeTab === 'income' ? 'border-blue-500 text-blue-600' : 'border-transparent hover:text-gray-600 hover:border-gray-300'}`}
                                    onClick={() => setActiveTab('income')}
                                >
                                    Income
                                </button>
                            </li>
                            <li>
                                <button
                                    className={`inline-block p-4 border-b-2 rounded-t-lg ${activeTab === 'trends' ? 'border-blue-500 text-blue-600' : 'border-transparent hover:text-gray-600 hover:border-gray-300'}`}
                                    onClick={() => setActiveTab('trends')}
                                >
                                    Trends
                                </button>
                            </li>
                        </ul>
                    </div>
                    
                    {/* Summary Cards - Always visible */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                            <h3 className="text-sm font-medium text-gray-500">Total Income</h3>
                            <p className="text-2xl font-bold text-green-600">{formatCurrency(summary.income)}</p>
                        </div>
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                            <h3 className="text-sm font-medium text-gray-500">Total Expenses</h3>
                            <p className="text-2xl font-bold text-red-600">{formatCurrency(summary.expense)}</p>
                        </div>
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                            <h3 className="text-sm font-medium text-gray-500">Net Balance</h3>
                            <p className={`text-2xl font-bold ${summary.balance >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                                {formatCurrency(summary.balance)}
                            </p>
                        </div>
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                            <h3 className="text-sm font-medium text-gray-500">Savings Rate</h3>
                            <p className={`text-2xl font-bold ${summary.savings_rate >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                                {summary.savings_rate}%
                            </p>
                        </div>
                    </div>
                    
                    {/* Overview Tab */}
                    {activeTab === 'overview' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                                <h3 className="text-lg font-semibold mb-4">Income vs Expenses</h3>
                                <div className="h-64">
                                    <Bar 
                                        data={{
                                            labels: ['Income', 'Expenses'],
                                            datasets: [
                                                {
                                                    label: 'Amount',
                                                    data: [summary.income, summary.expense],
                                                    backgroundColor: ['rgba(75, 192, 192, 0.6)', 'rgba(255, 99, 132, 0.6)'],
                                                }
                                            ]
                                        }}
                                        options={{
                                            responsive: true,
                                            maintainAspectRatio: false,
                                        }}
                                    />
                                </div>
                                <div className="mt-4">
                                    <Link
                                        href={route('reports.income-vs-expense')}
                                        className="text-blue-500 hover:text-blue-700"
                                    >
                                        View detailed income vs expense report &rarr;
                                    </Link>
                                </div>
                            </div>
                            
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                                <h3 className="text-lg font-semibold mb-4">Spending by Category</h3>
                                <div className="h-64 flex justify-center">
                                    {expenseCategories.length > 0 ? (
                                        <Pie 
                                            data={expensePieData}
                                            options={{
                                                responsive: true,
                                                maintainAspectRatio: false,
                                            }}
                                        />
                                    ) : (
                                        <div className="flex items-center justify-center h-full text-gray-500">
                                            No expense data available
                                        </div>
                                    )}
                                </div>
                            </div>
                            
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 md:col-span-2">
                                <h3 className="text-lg font-semibold mb-4">Income & Expense Trends</h3>
                                <div className="h-80">
                                    <Line 
                                        data={trendData}
                                        options={{
                                            responsive: true,
                                            maintainAspectRatio: false,
                                            scales: {
                                                y: {
                                                    beginAtZero: true
                                                }
                                            }
                                        }}
                                    />
                                </div>
                            </div>
                        </div>
                    )}
                    
                    {/* Expenses Tab */}
                    {activeTab === 'expenses' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                                <h3 className="text-lg font-semibold mb-4">Expense Breakdown</h3>
                                <div className="h-64 flex justify-center">
                                    {expenseCategories.length > 0 ? (
                                        <Pie 
                                            data={expensePieData}
                                            options={{
                                                responsive: true,
                                                maintainAspectRatio: false,
                                            }}
                                        />
                                    ) : (
                                        <div className="flex items-center justify-center h-full text-gray-500">
                                            No expense data available
                                        </div>
                                    )}
                                </div>
                            </div>
                            
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                                <h3 className="text-lg font-semibold mb-4">Top Expense Categories</h3>
                                <div className="space-y-4">
                                    {topExpenseCategories.length > 0 ? (
                                        topExpenseCategories.map((category) => (
                                            <div key={category.category_id} className="flex items-center">
                                                <div 
                                                    className="w-4 h-4 rounded-full mr-2" 
                                                    style={{ backgroundColor: category.category_color }}
                                                ></div>
                                                <div className="flex-1">
                                                    <div className="flex justify-between">
                                                        <span className="font-medium">{category.category_name}</span>
                                                        <span>{formatCurrency(category.total)}</span>
                                                    </div>
                                                    <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
                                                        <div 
                                                            className="bg-blue-600 h-2.5 rounded-full" 
                                                            style={{ width: `${category.percentage}%` }}
                                                        ></div>
                                                    </div>
                                                    <div className="text-xs text-right mt-1 text-gray-500">
                                                        {category.percentage}% of total expenses
                                                    </div>
                                                </div>
                                            </div>
                                        ))
                                    ) : (
                                        <div className="text-gray-500 text-center py-8">
                                            No expense data available
                                        </div>
                                    )}
                                </div>
                            </div>
                            
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 md:col-span-2">
                                <h3 className="text-lg font-semibold mb-4">All Expense Categories</h3>
                                <div className="overflow-x-auto">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead>
                                            <tr>
                                                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                                <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                                <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">% of Total</th>
                                                <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-200">
                                            {expenseCategories.map((category) => (
                                                <tr key={category.category_id}>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <div className="flex items-center">
                                                            <div 
                                                                className="w-3 h-3 rounded-full mr-2" 
                                                                style={{ backgroundColor: category.category_color }}
                                                            ></div>
                                                            {category.category_name}
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-right">{formatCurrency(category.total)}</td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-right">{category.percentage}%</td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-right">
                                                        <Link
                                                            href={route('reports.category-analysis', { category_id: category.category_id })}
                                                            className="text-blue-500 hover:text-blue-700"
                                                        >
                                                            Analyze
                                                        </Link>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                    
                                    {expenseCategories.length === 0 && (
                                        <div className="text-gray-500 text-center py-8">
                                            No expense data available
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                    
                    {/* Income Tab */}
                    {activeTab === 'income' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                                <h3 className="text-lg font-semibold mb-4">Income Breakdown</h3>
                                <div className="h-64 flex justify-center">
                                    {incomeCategories.length > 0 ? (
                                        <Pie 
                                            data={incomePieData}
                                            options={{
                                                responsive: true,
                                                maintainAspectRatio: false,
                                            }}
                                        />
                                    ) : (
                                        <div className="flex items-center justify-center h-full text-gray-500">
                                            No income data available
                                        </div>
                                    )}
                                </div>
                            </div>
                            
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                                <h3 className="text-lg font-semibold mb-4">Top Income Sources</h3>
                                <div className="space-y-4">
                                    {topIncomeCategories.length > 0 ? (
                                        topIncomeCategories.map((category) => (
                                            <div key={category.category_id} className="flex items-center">
                                                <div 
                                                    className="w-4 h-4 rounded-full mr-2" 
                                                    style={{ backgroundColor: category.category_color }}
                                                ></div>
                                                <div className="flex-1">
                                                    <div className="flex justify-between">
                                                        <span className="font-medium">{category.category_name}</span>
                                                        <span>{formatCurrency(category.total)}</span>
                                                    </div>
                                                    <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
                                                        <div 
                                                            className="bg-green-600 h-2.5 rounded-full" 
                                                            style={{ width: `${category.percentage}%` }}
                                                        ></div>
                                                    </div>
                                                    <div className="text-xs text-right mt-1 text-gray-500">
                                                        {category.percentage}% of total income
                                                    </div>
                                                </div>
                                            </div>
                                        ))
                                    ) : (
                                        <div className="text-gray-500 text-center py-8">
                                            No income data available
                                        </div>
                                    )}
                                </div>
                            </div>
                            
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 md:col-span-2">
                                <h3 className="text-lg font-semibold mb-4">All Income Categories</h3>
                                <div className="overflow-x-auto">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead>
                                            <tr>
                                                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                                <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                                <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">% of Total</th>
                                                <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-200">
                                            {incomeCategories.map((category) => (
                                                <tr key={category.category_id}>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <div className="flex items-center">
                                                            <div 
                                                                className="w-3 h-3 rounded-full mr-2" 
                                                                style={{ backgroundColor: category.category_color }}
                                                            ></div>
                                                            {category.category_name}
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-right">{formatCurrency(category.total)}</td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-right">{category.percentage}%</td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-right">
                                                        <Link
                                                            href={route('reports.category-analysis', { category_id: category.category_id })}
                                                            className="text-blue-500 hover:text-blue-700"
                                                        >
                                                            Analyze
                                                        </Link>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                    
                                    {incomeCategories.length === 0 && (
                                        <div className="text-gray-500 text-center py-8">
                                            No income data available
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                    
                    {/* Trends Tab */}
                    {activeTab === 'trends' && (
                        <div className="grid grid-cols-1 gap-6">
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                                <h3 className="text-lg font-semibold mb-4">Income & Expense Trends</h3>
                                <div className="h-96">
                                    <Line 
                                        key={`trends-line-chart-${filters.period}-${JSON.stringify(chartData)}`}
                                        data={trendData}
                                        options={{
                                            responsive: true,
                                            maintainAspectRatio: false,
                                            scales: {
                                                y: {
                                                    beginAtZero: true
                                                }
                                            }
                                        }}
                                    />
                                </div>
                            </div>
                            
                            <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                                <h3 className="text-lg font-semibold mb-4">Income vs Expense Comparison</h3>
                                <div className="h-80">
                                    <Bar 
                                        key={`trends-bar-chart-${filters.period}-${JSON.stringify(chartData)}`}
                                        data={{
                                            labels: chartData.labels,
                                            datasets: [
                                                {
                                                    label: 'Income',
                                                    data: chartData.income,
                                                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                                                },
                                                {
                                                    label: 'Expenses',
                                                    data: chartData.expense,
                                                    backgroundColor: 'rgba(255, 99, 132, 0.6)',
                                                }
                                            ]
                                        }}
                                        options={{
                                            responsive: true,
                                            maintainAspectRatio: false,
                                            scales: {
                                                y: {
                                                    beginAtZero: true
                                                }
                                            }
                                        }}
                                    />
                                </div>
                                <div className="mt-4">
                                    <Link
                                        href={route('reports.income-vs-expense')}
                                        className="text-blue-500 hover:text-blue-700"
                                    >
                                        View detailed income vs expense report &rarr;
                                    </Link>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </AuthenticatedLayout>
    );
}