import React from 'react';
import { Head, Link } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { formatCurrency } from '@/utils';
import { ArrowRightIcon } from '@heroicons/react/24/outline';

export default function Summary({ auth, statistics, upcomingGoals }) {
    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                <h2 className="font-semibold text-xl text-gray-800 leading-tight">Goals Summary</h2>
            }
        >
            <Head title="Goals Summary" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                        {/* Total Goals Card */}
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="p-6">
                                <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Total Goals</h3>
                                <p className="text-3xl font-bold">{statistics.totalGoals}</p>
                                <div className="mt-2 flex space-x-2">
                                    <span className="text-sm text-green-600">{statistics.completedGoals} Completed</span>
                                    <span className="text-sm text-blue-600">{statistics.inProgressGoals} In Progress</span>
                                    <span className="text-sm text-red-600">{statistics.cancelledGoals} Cancelled</span>
                                </div>
                            </div>
                        </div>

                        {/* Total Target Amount Card */}
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="p-6">
                                <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Total Target Amount</h3>
                                <p className="text-3xl font-bold">{formatCurrency(statistics.totalTargetAmount)}</p>
                            </div>
                        </div>

                        {/* Current Progress Card */}
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="p-6">
                                <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Current Progress</h3>
                                <p className="text-3xl font-bold">{formatCurrency(statistics.totalCurrentAmount)}</p>
                                <div className="mt-2">
                                    <span className="text-sm text-gray-600">
                                        {formatCurrency(statistics.totalTargetAmount - statistics.totalCurrentAmount)} remaining
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* Overall Progress Card */}
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="p-6">
                                <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Overall Progress</h3>
                                <p className="text-3xl font-bold">{statistics.overallProgress}%</p>
                                <div className="w-full bg-gray-200 rounded-full h-2.5 mt-3">
                                    <div 
                                        className="bg-indigo-600 h-2.5 rounded-full" 
                                        style={{ width: `${statistics.overallProgress}%` }}
                                    ></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Upcoming Goals Section */}
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                        <div className="p-6">
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-lg font-medium text-gray-900">Upcoming Goals</h3>
                                <Link 
                                    href={route('goals.index')} 
                                    className="text-indigo-600 hover:text-indigo-900 flex items-center"
                                >
                                    View All
                                    <ArrowRightIcon className="w-4 h-4 ml-1" />
                                </Link>
                            </div>
                            
                            {upcomingGoals.length === 0 ? (
                                <p className="text-gray-500">No upcoming goals found.</p>
                            ) : (
                                <div className="overflow-x-auto">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead className="bg-gray-50">
                                            <tr>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Name
                                                </th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Target Date
                                                </th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Target Amount
                                                </th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Progress
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-200">
                                            {upcomingGoals.map((goal) => {
                                                return (
                                                    <tr key={goal.id}>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <Link 
                                                                href={route('goals.show', goal.id)} 
                                                                className="text-indigo-600 hover:text-indigo-900 font-medium"
                                                            >
                                                                {goal.name}
                                                            </Link>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {new Date(goal.target_date).toLocaleDateString()}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {formatCurrency(goal.target_amount)}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                                                                <div 
                                                                    className="bg-indigo-600 h-2.5 rounded-full" 
                                                                    style={{ width: `${goal.progress_percentage}%` }}
                                                                ></div>
                                                            </div>
                                                            <span className="text-xs text-gray-500 mt-1">{goal.progress_percentage}%</span>
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Quick Links */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="p-6">
                                <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
                                <div className="space-y-2">
                                    <Link 
                                        href={route('goals.create')} 
                                        className="block w-full py-2 px-4 bg-indigo-600 text-white rounded-md text-center hover:bg-indigo-700 transition"
                                    >
                                        Create New Goal
                                    </Link>
                                    <Link 
                                        href={route('goals.index')} 
                                        className="block w-full py-2 px-4 bg-white border border-gray-300 text-gray-700 rounded-md text-center hover:bg-gray-50 transition"
                                    >
                                        Manage Goals
                                    </Link>
                                </div>
                            </div>
                        </div>
                        
                        <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="p-6">
                                <h3 className="text-lg font-medium text-gray-900 mb-4">Tips for Success</h3>
                                <ul className="list-disc pl-5 space-y-2 text-gray-600">
                                    <li>Set realistic and achievable financial goals</li>
                                    <li>Break large goals into smaller milestones</li>
                                    <li>Regularly track your progress</li>
                                    <li>Adjust your goals as your financial situation changes</li>
                                    <li>Celebrate your achievements along the way</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}