import React, { useState } from 'react';
import { Head, Link, router } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { PlusIcon } from '@heroicons/react/24/solid';
import { PencilIcon, TrashIcon, ArrowUpIcon, ArrowDownIcon } from '@heroicons/react/24/outline';
import { formatCurrency } from '@/utils';

export default function Index({ auth, goals }) {
    const [sortField, setSortField] = useState('target_date');
    const [sortDirection, setSortDirection] = useState('asc');

    const handleSort = (field) => {
        if (sortField === field) {
            setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
        } else {
            setSortField(field);
            setSortDirection('asc');
        }
    };

    const sortedGoals = [...goals].sort((a, b) => {
        let aValue = a[sortField];
        let bValue = b[sortField];

        if (sortField === 'target_date') {
            aValue = new Date(aValue);
            bValue = new Date(bValue);
        }

        if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
        return 0;
    });

    const handleDelete = (id) => {
        if (confirm('Are you sure you want to delete this goal?')) {
            router.delete(route('goals.destroy', id));
        }
    };

    const getPriorityColor = (priority) => {
        switch (priority) {
            case 'high': return 'text-red-600';
            case 'medium': return 'text-yellow-600';
            case 'low': return 'text-green-600';
            default: return 'text-gray-600';
        }
    };

    const getStatusBadge = (status) => {
        switch (status) {
            case 'completed':
                return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">Completed</span>;
            case 'in_progress':
                return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">In Progress</span>;
            case 'cancelled':
                return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">Cancelled</span>;
            default:
                return null;
        }
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                <div className="flex justify-between items-center">
                    <h2 className="font-semibold text-xl text-gray-800 leading-tight">Financial Goals</h2>
                    <Link
                        href={route('goals.create')}
                        className="px-4 py-2 bg-indigo-600 text-white rounded-md flex items-center hover:bg-indigo-700 transition"
                    >
                        <PlusIcon className="w-4 h-4 mr-2" />
                        New Goal
                    </Link>
                </div>
            }
        >
            <Head title="Financial Goals" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900">
                            {goals.length === 0 ? (
                                <div className="text-center py-8">
                                    <h3 className="text-lg font-medium text-gray-900">No goals yet</h3>
                                    <p className="mt-1 text-sm text-gray-500">Get started by creating a new financial goal.</p>
                                    <div className="mt-6">
                                        <Link
                                            href={route('goals.create')}
                                            className="px-4 py-2 bg-indigo-600 text-white rounded-md inline-flex items-center hover:bg-indigo-700 transition"
                                        >
                                            <PlusIcon className="w-4 h-4 mr-2" />
                                            Create Goal
                                        </Link>
                                    </div>
                                </div>
                            ) : (
                                <div className="overflow-x-auto">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead className="bg-gray-50">
                                            <tr>
                                                <th 
                                                    scope="col" 
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                                                    onClick={() => handleSort('name')}
                                                >
                                                    <div className="flex items-center">
                                                        Name
                                                        {sortField === 'name' && (
                                                            sortDirection === 'asc' ? 
                                                            <ArrowUpIcon className="w-4 h-4 ml-1" /> : 
                                                            <ArrowDownIcon className="w-4 h-4 ml-1" />
                                                        )}
                                                    </div>
                                                </th>
                                                <th 
                                                    scope="col" 
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                                                    onClick={() => handleSort('target_amount')}
                                                >
                                                    <div className="flex items-center">
                                                        Target Amount
                                                        {sortField === 'target_amount' && (
                                                            sortDirection === 'asc' ? 
                                                            <ArrowUpIcon className="w-4 h-4 ml-1" /> : 
                                                            <ArrowDownIcon className="w-4 h-4 ml-1" />
                                                        )}
                                                    </div>
                                                </th>
                                                <th 
                                                    scope="col" 
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                                                    onClick={() => handleSort('current_amount')}
                                                >
                                                    <div className="flex items-center">
                                                        Current Amount
                                                        {sortField === 'current_amount' && (
                                                            sortDirection === 'asc' ? 
                                                            <ArrowUpIcon className="w-4 h-4 ml-1" /> : 
                                                            <ArrowDownIcon className="w-4 h-4 ml-1" />
                                                        )}
                                                    </div>
                                                </th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Progress
                                                </th>
                                                <th 
                                                    scope="col" 
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                                                    onClick={() => handleSort('target_date')}
                                                >
                                                    <div className="flex items-center">
                                                        Target Date
                                                        {sortField === 'target_date' && (
                                                            sortDirection === 'asc' ? 
                                                            <ArrowUpIcon className="w-4 h-4 ml-1" /> : 
                                                            <ArrowDownIcon className="w-4 h-4 ml-1" />
                                                        )}
                                                    </div>
                                                </th>
                                                <th 
                                                    scope="col" 
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                                                    onClick={() => handleSort('priority')}
                                                >
                                                    <div className="flex items-center">
                                                        Priority
                                                        {sortField === 'priority' && (
                                                            sortDirection === 'asc' ? 
                                                            <ArrowUpIcon className="w-4 h-4 ml-1" /> : 
                                                            <ArrowDownIcon className="w-4 h-4 ml-1" />
                                                        )}
                                                    </div>
                                                </th>
                                                <th 
                                                    scope="col" 
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                                                    onClick={() => handleSort('status')}
                                                >
                                                    <div className="flex items-center">
                                                        Status
                                                        {sortField === 'status' && (
                                                            sortDirection === 'asc' ? 
                                                            <ArrowUpIcon className="w-4 h-4 ml-1" /> : 
                                                            <ArrowDownIcon className="w-4 h-4 ml-1" />
                                                        )}
                                                    </div>
                                                </th>
                                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Actions
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-200">
                                            {sortedGoals.map((goal) => {
                                                return (
                                                    <tr key={goal.id}>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <Link 
                                                                href={route('goals.show', goal.id)} 
                                                                className="text-indigo-600 hover:text-indigo-900 font-medium"
                                                            >
                                                                {goal.name}
                                                            </Link>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {formatCurrency(goal.target_amount)}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {formatCurrency(goal.current_amount)}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                                                                <div 
                                                                    className="bg-indigo-600 h-2.5 rounded-full" 
                                                                    style={{ width: `${goal.progress_percentage}%` }}
                                                                ></div>
                                                            </div>
                                                            <span className="text-xs text-gray-500 mt-1">{goal.progress_percentage}%</span>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {new Date(goal.target_date).toLocaleDateString()}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <span className={`capitalize ${getPriorityColor(goal.priority)}`}>
                                                                {goal.priority}
                                                            </span>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            {getStatusBadge(goal.status)}
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                            <div className="flex justify-end space-x-2">
                                                                <Link
                                                                    href={route('goals.edit', goal.id)}
                                                                    className="text-indigo-600 hover:text-indigo-900"
                                                                >
                                                                    <PencilIcon className="w-5 h-5" />
                                                                </Link>
                                                                <button
                                                                    onClick={() => handleDelete(goal.id)}
                                                                    className="text-red-600 hover:text-red-900"
                                                                >
                                                                    <TrashIcon className="w-5 h-5" />
                                                                </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}