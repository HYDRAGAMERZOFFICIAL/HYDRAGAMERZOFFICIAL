import React, { useState } from 'react';
import { Head, Link, useForm } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { PencilIcon, ArrowLeftIcon } from '@heroicons/react/24/outline';
import { formatCurrency } from '@/utils';
import PrimaryButton from '@/Components/PrimaryButton';
import TextInput from '@/Components/TextInput';
import InputLabel from '@/Components/InputLabel';
import InputError from '@/Components/InputError';

export default function Show({ auth, goal }) {
    const [showUpdateForm, setShowUpdateForm] = useState(false);
    
    const { data, setData, post, processing, errors, reset } = useForm({
        amount: '',
        operation: 'add',
    });
    
    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('goals.update-amount', goal.id), {
            onSuccess: () => {
                reset();
                setShowUpdateForm(false);
            },
        });
    };
    
    // Use the computed attributes from the model
    const progressPercentage = goal.progress_percentage;
    const remainingAmount = goal.remaining_amount;
    
    const getPriorityBadge = (priority) => {
        switch (priority) {
            case 'high':
                return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">High Priority</span>;
            case 'medium':
                return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">Medium Priority</span>;
            case 'low':
                return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">Low Priority</span>;
            default:
                return null;
        }
    };
    
    const getStatusBadge = (status) => {
        switch (status) {
            case 'completed':
                return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">Completed</span>;
            case 'in_progress':
                return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">In Progress</span>;
            case 'cancelled':
                return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">Cancelled</span>;
            default:
                return null;
        }
    };
    
    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                <div className="flex items-center">
                    <Link href={route('goals.index')} className="mr-3">
                        <ArrowLeftIcon className="w-5 h-5 text-gray-500" />
                    </Link>
                    <h2 className="font-semibold text-xl text-gray-800 leading-tight">Goal Details</h2>
                </div>
            }
        >
            <Head title={`Goal: ${goal.name}`} />

            <div className="py-12">
                <div className="max-w-4xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900">
                            <div className="flex justify-between items-start mb-6">
                                <div>
                                    <h1 className="text-2xl font-bold">{goal.name}</h1>
                                    <div className="flex space-x-2 mt-2">
                                        {getPriorityBadge(goal.priority)}
                                        {getStatusBadge(goal.status)}
                                    </div>
                                </div>
                                <Link href={route('goals.edit', goal.id)} className="text-indigo-600 hover:text-indigo-900">
                                    <PencilIcon className="w-5 h-5" />
                                </Link>
                            </div>
                            
                            {goal.description && (
                                <div className="mb-6">
                                    <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Description</h3>
                                    <p className="text-gray-700">{goal.description}</p>
                                </div>
                            )}
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                <div>
                                    <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Target Amount</h3>
                                    <p className="text-xl font-semibold">{formatCurrency(goal.target_amount)}</p>
                                </div>
                                <div>
                                    <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Current Amount</h3>
                                    <p className="text-xl font-semibold">{formatCurrency(goal.current_amount)}</p>
                                </div>
                            </div>
                            
                            <div className="mb-6">
                                <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Progress</h3>
                                <div className="w-full bg-gray-200 rounded-full h-4 mb-2">
                                    <div 
                                        className="bg-indigo-600 h-4 rounded-full" 
                                        style={{ width: `${progressPercentage}%` }}
                                    ></div>
                                </div>
                                <div className="flex justify-between text-sm">
                                    <span>{progressPercentage}% complete</span>
                                    <span>{formatCurrency(remainingAmount)} remaining</span>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                <div>
                                    <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Target Date</h3>
                                    <p className="text-gray-700">{new Date(goal.target_date).toLocaleDateString()}</p>
                                </div>
                                <div>
                                    <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2">Created On</h3>
                                    <p className="text-gray-700">{new Date(goal.created_at).toLocaleDateString()}</p>
                                </div>
                            </div>
                            
                            {goal.status === 'in_progress' && (
                                <div className="mt-8">
                                    {!showUpdateForm ? (
                                        <PrimaryButton onClick={() => setShowUpdateForm(true)}>
                                            Update Progress
                                        </PrimaryButton>
                                    ) : (
                                        <div className="bg-gray-50 p-4 rounded-lg">
                                            <h3 className="font-medium text-gray-900 mb-4">Update Goal Progress</h3>
                                            <form onSubmit={handleSubmit}>
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                                    <div>
                                                        <InputLabel htmlFor="amount" value="Amount" />
                                                        <TextInput
                                                            id="amount"
                                                            type="number"
                                                            name="amount"
                                                            value={data.amount}
                                                            className="mt-1 block w-full"
                                                            onChange={(e) => setData('amount', e.target.value)}
                                                            min="0"
                                                            step="1"
                                                            required
                                                        />
                                                        <InputError message={errors.amount} className="mt-2" />
                                                    </div>
                                                    
                                                    <div>
                                                        <InputLabel htmlFor="operation" value="Operation" />
                                                        <select
                                                            id="operation"
                                                            name="operation"
                                                            value={data.operation}
                                                            className="mt-1 block w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm"
                                                            onChange={(e) => setData('operation', e.target.value)}
                                                            required
                                                        >
                                                            <option value="add">Add to current amount</option>
                                                            <option value="subtract">Subtract from current amount</option>
                                                            <option value="set">Set as new amount</option>
                                                        </select>
                                                        <InputError message={errors.operation} className="mt-2" />
                                                    </div>
                                                </div>
                                                
                                                <div className="flex items-center justify-end">
                                                    <button
                                                        type="button"
                                                        className="text-gray-500 mr-4"
                                                        onClick={() => {
                                                            setShowUpdateForm(false);
                                                            reset();
                                                        }}
                                                    >
                                                        Cancel
                                                    </button>
                                                    <PrimaryButton type="submit" disabled={processing}>
                                                        Update
                                                    </PrimaryButton>
                                                </div>
                                            </form>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}