import React from 'react';
import { Head, Link, useForm } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import InputLabel from '@/Components/InputLabel';
import TextInput from '@/Components/TextInput';
import InputError from '@/Components/InputError';
import PrimaryButton from '@/Components/PrimaryButton';
import SecondaryButton from '@/Components/SecondaryButton';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';

export default function Create({ auth }) {
    const { data, setData, post, processing, errors, reset } = useForm({
        name: '',
        description: '',
        target_amount: '',
        current_amount: '0',
        target_date: '',
        priority: 'medium',
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('goals.store'), {
            onSuccess: () => reset(),
        });
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                <div className="flex items-center">
                    <Link href={route('goals.index')} className="mr-3">
                        <ArrowLeftIcon className="w-5 h-5 text-gray-500" />
                    </Link>
                    <h2 className="font-semibold text-xl text-gray-800 leading-tight">Create New Goal</h2>
                </div>
            }
        >
            <Head title="Create Goal" />

            <div className="py-12">
                <div className="max-w-3xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900">
                            <form onSubmit={handleSubmit}>
                                <div className="mb-4">
                                    <InputLabel htmlFor="name" value="Goal Name" />
                                    <TextInput
                                        id="name"
                                        type="text"
                                        name="name"
                                        value={data.name}
                                        className="mt-1 block w-full"
                                        onChange={(e) => setData('name', e.target.value)}
                                        required
                                    />
                                    <InputError message={errors.name} className="mt-2" />
                                </div>

                                <div className="mb-4">
                                    <InputLabel htmlFor="description" value="Description (Optional)" />
                                    <textarea
                                        id="description"
                                        name="description"
                                        value={data.description}
                                        className="mt-1 block w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm"
                                        onChange={(e) => setData('description', e.target.value)}
                                        rows={3}
                                    />
                                    <InputError message={errors.description} className="mt-2" />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                    <div>
                                        <InputLabel htmlFor="target_amount" value="Target Amount" />
                                        <TextInput
                                            id="target_amount"
                                            type="number"
                                            name="target_amount"
                                            value={data.target_amount}
                                            className="mt-1 block w-full"
                                            onChange={(e) => setData('target_amount', e.target.value)}
                                            min="0"
                                            step="1"
                                            required
                                        />
                                        <InputError message={errors.target_amount} className="mt-2" />
                                    </div>

                                    <div>
                                        <InputLabel htmlFor="current_amount" value="Current Amount (Optional)" />
                                        <TextInput
                                            id="current_amount"
                                            type="number"
                                            name="current_amount"
                                            value={data.current_amount}
                                            className="mt-1 block w-full"
                                            onChange={(e) => setData('current_amount', e.target.value)}
                                            min="0"
                                            step="1"
                                        />
                                        <InputError message={errors.current_amount} className="mt-2" />
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                    <div>
                                        <InputLabel htmlFor="target_date" value="Target Date" />
                                        <TextInput
                                            id="target_date"
                                            type="date"
                                            name="target_date"
                                            value={data.target_date}
                                            className="mt-1 block w-full"
                                            onChange={(e) => setData('target_date', e.target.value)}
                                            required
                                        />
                                        <InputError message={errors.target_date} className="mt-2" />
                                    </div>

                                    <div>
                                        <InputLabel htmlFor="priority" value="Priority" />
                                        <select
                                            id="priority"
                                            name="priority"
                                            value={data.priority}
                                            className="mt-1 block w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm"
                                            onChange={(e) => setData('priority', e.target.value)}
                                            required
                                        >
                                            <option value="low">Low</option>
                                            <option value="medium">Medium</option>
                                            <option value="high">High</option>
                                        </select>
                                        <InputError message={errors.priority} className="mt-2" />
                                    </div>
                                </div>

                                <div className="flex items-center justify-end mt-6">
                                    <Link href={route('goals.index')}>
                                        <SecondaryButton className="mr-2">Cancel</SecondaryButton>
                                    </Link>
                                    <PrimaryButton type="submit" disabled={processing}>
                                        Create Goal
                                    </PrimaryButton>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}