import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';
import { useState } from 'react';

export default function Categories({ auth, categories, filters = {} }) {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isFilterOpen, setIsFilterOpen] = useState(false);
    
    const { data, setData, post, processing, errors, reset } = useForm({
        name: '',
        type: 'expense',
        color: '#000000',
        description: ''
    });
    
    const { data: filterData, setData: setFilterData, get: applyFilter, processing: filterProcessing } = useForm({
        type: filters.type || '',
        search: filters.search || '',
        sort_field: filters.sort_field || 'name',
        sort_direction: filters.sort_direction || 'asc'
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('categories.store'), {
            onSuccess: () => {
                reset();
                setIsModalOpen(false);
            }
        });
    };
    
    const handleFilterSubmit = (e) => {
        e.preventDefault();
        applyFilter(route('categories.index'), {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => {
                setIsFilterOpen(false);
            }
        });
    };
    
    const resetFilters = () => {
        setFilterData({
            type: '',
            search: '',
            sort_field: 'name',
            sort_direction: 'asc'
        });
        
        applyFilter(route('categories.index'), {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => {
                setIsFilterOpen(false);
            }
        });
    };
    
    const handleSort = (field) => {
        const direction = 
            filterData.sort_field === field && filterData.sort_direction === 'asc' 
                ? 'desc' 
                : 'asc';
                
        setFilterData({
            ...filterData,
            sort_field: field,
            sort_direction: direction
        });
        
        applyFilter(route('categories.index'), {
            preserveState: true,
            preserveScroll: true
        });
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Categories</h2>}
        >
            <Head title="Categories" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="mb-6 flex justify-between">
                        <div className="flex space-x-2">
                            <button
                                onClick={() => setIsModalOpen(true)}
                                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600"
                            >
                                Add Category
                            </button>
                            <button
                                onClick={() => setIsFilterOpen(!isFilterOpen)}
                                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300"
                            >
                                {isFilterOpen ? 'Hide Filters' : 'Show Filters'}
                            </button>
                        </div>
                        
                        {Object.values(filterData).some(value => value !== '' && value !== 'name' && value !== 'asc') && (
                            <button
                                onClick={resetFilters}
                                className="text-gray-600 hover:text-gray-900"
                            >
                                Clear Filters
                            </button>
                        )}
                    </div>
                    
                    {isFilterOpen && (
                        <div className="mb-6 bg-white p-4 rounded-lg shadow">
                            <h3 className="text-lg font-semibold mb-4">Filter Categories</h3>
                            <form onSubmit={handleFilterSubmit}>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-gray-700 text-sm font-bold mb-2">
                                            Type
                                        </label>
                                        <select
                                            value={filterData.type}
                                            onChange={e => setFilterData('type', e.target.value)}
                                            className="w-full border rounded px-3 py-2"
                                        >
                                            <option value="">All Types</option>
                                            <option value="expense">Expense</option>
                                            <option value="income">Income</option>
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label className="block text-gray-700 text-sm font-bold mb-2">
                                            Search
                                        </label>
                                        <input
                                            type="text"
                                            value={filterData.search}
                                            onChange={e => setFilterData('search', e.target.value)}
                                            placeholder="Search by name or description"
                                            className="w-full border rounded px-3 py-2"
                                        />
                                    </div>
                                </div>
                                
                                <div className="mt-4 flex justify-end">
                                    <button
                                        type="button"
                                        onClick={resetFilters}
                                        className="mr-2 bg-gray-300 text-gray-700 px-4 py-2 rounded"
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="submit"
                                        disabled={filterProcessing}
                                        className="bg-blue-500 text-white px-4 py-2 rounded"
                                    >
                                        Apply Filters
                                    </button>
                                </div>
                            </form>
                        </div>
                    )}

                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                {categories.map((category) => (
                                    <div
                                        key={category.id}
                                        className="border rounded-lg p-4 relative"
                                        style={{ borderLeftColor: category.color, borderLeftWidth: '4px' }}
                                    >
                                        <div className="absolute top-2 right-2 flex space-x-2">
                                            <Link
                                                href={route('categories.edit', category.id)}
                                                className="text-gray-500 hover:text-gray-700"
                                            >
                                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                                </svg>
                                            </Link>
                                            <Link
                                                href={route('categories.destroy', category.id)}
                                                method="delete"
                                                as="button"
                                                className="text-red-500 hover:text-red-700"
                                                onClick={(e) => {
                                                    if (!confirm('Are you sure you want to delete this category?')) {
                                                        e.preventDefault();
                                                    }
                                                }}
                                            >
                                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                </svg>
                                            </Link>
                                        </div>
                                        
                                        <Link href={route('categories.show', category.id)}>
                                            <h3 className="text-lg font-semibold">{category.name}</h3>
                                            <p className="text-sm text-gray-600 mt-1">
                                                <span className={`inline-block px-2 py-1 rounded-full text-xs ${
                                                    category.type === 'income' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                                }`}>
                                                    {category.type}
                                                </span>
                                            </p>
                                            {category.description && (
                                                <p className="mt-2 text-gray-600 line-clamp-2">{category.description}</p>
                                            )}
                                        </Link>
                                    </div>
                                ))}
                            </div>
                            
                            {categories.length === 0 && (
                                <div className="text-center py-4">
                                    <p className="text-gray-500">No categories found</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white p-6 rounded-lg w-full max-w-md">
                        <h3 className="text-lg font-semibold mb-4">Add Category</h3>
                        <form onSubmit={handleSubmit}>
                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Name
                                </label>
                                <input
                                    type="text"
                                    value={data.name}
                                    onChange={e => setData('name', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                />
                                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Type
                                </label>
                                <select
                                    value={data.type}
                                    onChange={e => setData('type', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                >
                                    <option value="expense">Expense</option>
                                    <option value="income">Income</option>
                                </select>
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Color
                                </label>
                                <div className="flex items-center">
                                    <input
                                        type="color"
                                        value={data.color}
                                        onChange={e => setData('color', e.target.value)}
                                        className="w-12 h-10 border rounded mr-2"
                                    />
                                    <input
                                        type="text"
                                        value={data.color}
                                        onChange={e => setData('color', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                        placeholder="#000000"
                                    />
                                </div>
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Description
                                </label>
                                <textarea
                                    value={data.description}
                                    onChange={e => setData('description', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                    rows="3"
                                />
                            </div>

                            <div className="flex justify-end gap-4">
                                <button
                                    type="button"
                                    onClick={() => setIsModalOpen(false)}
                                    className="bg-gray-300 text-gray-700 px-4 py-2 rounded"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={processing}
                                    className="bg-blue-500 text-white px-4 py-2 rounded"
                                >
                                    Save
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </AuthenticatedLayout>
    );
}
