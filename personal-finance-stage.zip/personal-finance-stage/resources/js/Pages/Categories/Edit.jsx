import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, Link } from '@inertiajs/react';

export default function Edit({ auth, category }) {
    const { data, setData, patch, processing, errors } = useForm({
        name: category.name,
        type: category.type,
        color: category.color || '#000000',
        description: category.description || ''
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        patch(route('categories.update', category.id), {
            onSuccess: () => {
                // Redirect is handled by the controller
            }
        });
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Edit Category</h2>}
        >
            <Head title="Edit Category" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6">
                            <div className="mb-6">
                                <Link
                                    href={route('categories.index')}
                                    className="text-blue-500 hover:text-blue-700"
                                >
                                    &larr; Back to Categories
                                </Link>
                            </div>

                            <form onSubmit={handleSubmit}>
                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Name
                                    </label>
                                    <input
                                        type="text"
                                        value={data.name}
                                        onChange={e => setData('name', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    />
                                    {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Type
                                    </label>
                                    <select
                                        value={data.type}
                                        onChange={e => setData('type', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    >
                                        <option value="expense">Expense</option>
                                        <option value="income">Income</option>
                                    </select>
                                    {errors.type && <p className="text-red-500 text-xs mt-1">{errors.type}</p>}
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Color
                                    </label>
                                    <div className="flex items-center">
                                        <input
                                            type="color"
                                            value={data.color}
                                            onChange={e => setData('color', e.target.value)}
                                            className="w-12 h-10 border rounded mr-2"
                                        />
                                        <input
                                            type="text"
                                            value={data.color}
                                            onChange={e => setData('color', e.target.value)}
                                            className="w-full border rounded px-3 py-2"
                                            placeholder="#000000"
                                        />
                                    </div>
                                    {errors.color && <p className="text-red-500 text-xs mt-1">{errors.color}</p>}
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Description
                                    </label>
                                    <textarea
                                        value={data.description}
                                        onChange={e => setData('description', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                        rows="3"
                                    />
                                    {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description}</p>}
                                </div>

                                <div className="flex justify-end gap-4">
                                    <Link
                                        href={route('categories.index')}
                                        className="bg-gray-300 text-gray-700 px-4 py-2 rounded"
                                    >
                                        Cancel
                                    </Link>
                                    <button
                                        type="submit"
                                        disabled={processing}
                                        className="bg-blue-500 text-white px-4 py-2 rounded"
                                    >
                                        Update
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}