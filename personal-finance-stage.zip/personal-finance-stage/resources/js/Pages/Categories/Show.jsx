import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';

export default function Show({ auth, category, stats }) {
    const deleteForm = useForm({});
    
    const handleDelete = () => {
        if (confirm('Are you sure you want to delete this category?')) {
            deleteForm.delete(route('categories.destroy', category.id));
        }
    };
    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Category Details</h2>}
        >
            <Head title={`Category: ${category.name}`} />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="mb-6">
                        <Link
                            href={route('categories.index')}
                            className="text-blue-500 hover:text-blue-700"
                        >
                            &larr; Back to Categories
                        </Link>
                    </div>

                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h1 className="text-2xl font-bold mb-2">{category.name}</h1>
                                    <div className="mb-4">
                                        <span className={`inline-block px-3 py-1 rounded-full text-sm ${
                                            category.type === 'income' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                        }`}>
                                            {category.type.charAt(0).toUpperCase() + category.type.slice(1)}
                                        </span>
                                    </div>
                                </div>
                                <div className="flex space-x-2">
                                    <Link
                                        href={route('categories.edit', category.id)}
                                        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                                    >
                                        Edit
                                    </Link>
                                    <button
                                        type="button"
                                        className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
                                        onClick={handleDelete}
                                    >
                                        Delete
                                    </button>
                                </div>
                            </div>

                            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="border rounded-lg p-4" style={{ borderLeftColor: category.color, borderLeftWidth: '4px' }}>
                                    <h3 className="text-lg font-semibold mb-4">Category Information</h3>
                                    
                                    <div className="mb-4">
                                        <p className="text-sm text-gray-600">Color:</p>
                                        <div className="flex items-center mt-1">
                                            <div 
                                                className="w-6 h-6 rounded mr-2" 
                                                style={{ backgroundColor: category.color }}
                                            ></div>
                                            <span>{category.color}</span>
                                        </div>
                                    </div>
                                    
                                    {category.description && (
                                        <div className="mb-4">
                                            <p className="text-sm text-gray-600">Description:</p>
                                            <p className="mt-1">{category.description}</p>
                                        </div>
                                    )}
                                    
                                    <div className="mb-4">
                                        <p className="text-sm text-gray-600">Created:</p>
                                        <p className="mt-1">{new Date(category.created_at).toLocaleDateString()}</p>
                                    </div>
                                    
                                    <div>
                                        <p className="text-sm text-gray-600">Last Updated:</p>
                                        <p className="mt-1">{new Date(category.updated_at).toLocaleDateString()}</p>
                                    </div>
                                </div>
                                
                                <div className="border rounded-lg p-4">
                                    <h3 className="text-lg font-semibold mb-4">Transaction Statistics</h3>
                                    
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="bg-gray-50 p-4 rounded-lg">
                                            <p className="text-sm text-gray-600">Total Transactions</p>
                                            <p className="text-2xl font-bold mt-1">{stats.transactionCount}</p>
                                        </div>
                                        
                                        <div className="bg-gray-50 p-4 rounded-lg">
                                            <p className="text-sm text-gray-600">Total Amount</p>
                                            <p className="text-2xl font-bold mt-1">
                                                {new Intl.NumberFormat('en-US', {
                                                    style: 'currency',
                                                    currency: 'INR'
                                                }).format(stats.totalAmount)}
                                            </p>
                                        </div>
                                    </div>
                                    
                                    {stats.transactionCount > 0 ? (
                                        <div className="mt-4">
                                            <Link
                                                href={route('transactions.index', { category_id: category.id })}
                                                className="text-blue-500 hover:text-blue-700"
                                            >
                                                View all transactions in this category &rarr;
                                            </Link>
                                        </div>
                                    ) : (
                                        <div className="mt-4 text-gray-500 text-center py-4">
                                            No transactions in this category yet
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}