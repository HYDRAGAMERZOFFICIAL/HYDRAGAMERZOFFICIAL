import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';

export default function Show({ auth, transaction }) {
    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Transaction Details</h2>}
        >
            <Head title="Transaction Details" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="mb-6 flex justify-between">
                        <Link
                            href={route('transactions.index')}
                            className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600"
                        >
                            Back to Transactions
                        </Link>
                        <div className="flex space-x-2">
                            <Link
                                href={route('transactions.edit', transaction.id)}
                                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600"
                            >
                                Edit
                            </Link>
                            <Link
                                href={route('transactions.destroy', transaction.id)}
                                method="delete"
                                as="button"
                                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600"
                            >
                                Delete
                            </Link>
                        </div>
                    </div>

                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <h3 className="text-lg font-semibold mb-4">Transaction Information</h3>
                                    <div className="space-y-4">
                                        <div>
                                            <p className="text-sm text-gray-600">Category</p>
                                            <p className="font-medium">{transaction.category.name}</p>
                                        </div>
                                        <div>
                                            <p className="text-sm text-gray-600">Amount</p>
                                            <p className="font-medium text-xl">₹{transaction.amount}</p>
                                        </div>
                                        <div>
                                            <p className="text-sm text-gray-600">Type</p>
                                            <p className={`inline-block px-2 py-1 rounded-full text-xs ${transaction.type === 'income' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                {transaction.type}
                                            </p>
                                        </div>
                                        <div>
                                            <p className="text-sm text-gray-600">Date</p>
                                            <p className="font-medium">{new Date(transaction.date).toLocaleDateString()}</p>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <h3 className="text-lg font-semibold mb-4">Additional Details</h3>
                                    <div className="space-y-4">
                                        <div>
                                            <p className="text-sm text-gray-600">Description</p>
                                            <p className="font-medium">{transaction.description || 'No description provided'}</p>
                                        </div>
                                        {transaction.attachment && (
                                            <div>
                                                <p className="text-sm text-gray-600">Attachment</p>
                                                <a 
                                                    href={`/storage/${transaction.attachment}`} 
                                                    target="_blank" 
                                                    className="text-blue-500 hover:underline"
                                                >
                                                    View Attachment
                                                </a>
                                            </div>
                                        )}
                                        <div>
                                            <p className="text-sm text-gray-600">Created At</p>
                                            <p className="font-medium">{new Date(transaction.created_at).toLocaleString()}</p>
                                        </div>
                                        <div>
                                            <p className="text-sm text-gray-600">Last Updated</p>
                                            <p className="font-medium">{new Date(transaction.updated_at).toLocaleString()}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}