import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';

export default function Edit({ auth, transaction, categories }) {
    const { data, setData, patch, processing, errors } = useForm({
        category_id: transaction.category_id,
        amount: transaction.amount,
        type: transaction.type,
        date: transaction.date,
        description: transaction.description || '',
        attachment: null
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        patch(route('transactions.update', transaction.id), {
            preserveScroll: true,
        });
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Edit Transaction</h2>}
        >
            <Head title="Edit Transaction" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="mb-6">
                        <Link
                            href={route('transactions.index')}
                            className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600"
                        >
                            Back to Transactions
                        </Link>
                    </div>

                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6">
                            <form onSubmit={handleSubmit}>
                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Category
                                    </label>
                                    <select
                                        value={data.category_id}
                                        onChange={e => setData('category_id', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    >
                                        <option value="">Select a category</option>
                                        {categories.map(category => (
                                            <option key={category.id} value={category.id}>
                                                {category.name}
                                            </option>
                                        ))}
                                    </select>
                                    {errors.category_id && <p className="text-red-500 text-xs mt-1">{errors.category_id}</p>}
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Amount
                                    </label>
                                    <input
                                        type="number"
                                        step="1"
                                        value={data.amount}
                                        onChange={e => setData('amount', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    />
                                    {errors.amount && <p className="text-red-500 text-xs mt-1">{errors.amount}</p>}
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Type
                                    </label>
                                    <select
                                        value={data.type}
                                        onChange={e => setData('type', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    >
                                        <option value="expense">Expense</option>
                                        <option value="income">Income</option>
                                    </select>
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Date
                                    </label>
                                    <input
                                        type="date"
                                        value={data.date}
                                        onChange={e => setData('date', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    />
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Description
                                    </label>
                                    <textarea
                                        value={data.description}
                                        onChange={e => setData('description', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    />
                                </div>

                                <div className="mb-4">
                                    {/* <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Attachment
                                    </label>
                                    <input
                                        type="file"
                                        onChange={e => setData('attachment', e.target.files[0])}
                                        className="w-full border rounded px-3 py-2"
                                    /> */}
                                    {transaction.attachment && (
                                        <div className="mt-2">
                                            <a 
                                                href={`/storage/${transaction.attachment}`} 
                                                target="_blank" 
                                                className="text-blue-500 hover:underline"
                                            >
                                                Current Attachment
                                            </a>
                                        </div>
                                    )}
                                </div>

                                <div className="flex justify-end">
                                    <button
                                        type="submit"
                                        disabled={processing}
                                        className="bg-blue-500 text-white px-4 py-2 rounded"
                                    >
                                        Update Transaction
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}