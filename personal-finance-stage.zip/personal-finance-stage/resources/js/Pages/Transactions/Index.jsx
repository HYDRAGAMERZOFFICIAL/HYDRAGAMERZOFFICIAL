import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, Link } from '@inertiajs/react';
import { useState } from 'react';

export default function Transactions({ auth, transactions, categories, filters = {} }) {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isFilterOpen, setIsFilterOpen] = useState(false);
    
    const { data, setData, post, processing, errors, reset } = useForm({
        category_id: '',
        amount: '',
        type: 'expense',
        date: new Date().toISOString().split('T')[0],
        description: '',
        attachment: null
    });
    
    const { data: filterData, setData: setFilterData, get: applyFilter, processing: filterProcessing } = useForm({
        category_id: filters.category_id || '',
        type: filters.type || '',
        date_from: filters.date_from || '',
        date_to: filters.date_to || '',
        amount_min: filters.amount_min || '',
        amount_max: filters.amount_max || '',
        search: filters.search || '',
        sort_field: filters.sort_field || 'date',
        sort_direction: filters.sort_direction || 'desc'
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('transactions.store'), {
            onSuccess: () => {
                reset();
                setIsModalOpen(false);
            }
        });
    };
    
    const handleFilterSubmit = (e) => {
        e.preventDefault();
        applyFilter(route('transactions.index'), {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => {
                setIsFilterOpen(false);
            }
        });
    };
    
    const resetFilters = () => {
        setFilterData({
            category_id: '',
            type: '',
            date_from: '',
            date_to: '',
            amount_min: '',
            amount_max: '',
            search: '',
            sort_field: 'date',
            sort_direction: 'desc'
        });
        
        applyFilter(route('transactions.index'), {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => {
                setIsFilterOpen(false);
            }
        });
    };
    
    const handleSort = (field) => {
        const direction = 
            filterData.sort_field === field && filterData.sort_direction === 'asc' 
                ? 'desc' 
                : 'asc';
                
        setFilterData({
            ...filterData,
            sort_field: field,
            sort_direction: direction
        });
        
        applyFilter(route('transactions.index'), {
            preserveState: true,
            preserveScroll: true
        });
    };
    
    const getSortIcon = (field) => {
        if (filterData.sort_field !== field) return null;
        
        return filterData.sort_direction === 'asc' 
            ? '↑' 
            : '↓';
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Transactions</h2>}
        >
            <Head title="Transactions" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="mb-6 flex justify-between">
                        <div className="flex space-x-2">
                            <button
                                onClick={() => setIsModalOpen(true)}
                                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600"
                            >
                                Add Transaction
                            </button>
                            <button
                                onClick={() => setIsFilterOpen(!isFilterOpen)}
                                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300"
                            >
                                {isFilterOpen ? 'Hide Filters' : 'Show Filters'}
                            </button>
                        </div>
                        
                        {Object.values(filterData).some(value => value !== '' && value !== 'date' && value !== 'desc') && (
                            <button
                                onClick={resetFilters}
                                className="text-gray-600 hover:text-gray-900"
                            >
                                Clear Filters
                            </button>
                        )}
                    </div>
                    
                    {isFilterOpen && (
                        <div className="mb-6 bg-white p-4 rounded-lg shadow">
                            <h3 className="text-lg font-semibold mb-4">Filter Transactions</h3>
                            <form onSubmit={handleFilterSubmit}>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <label className="block text-gray-700 text-sm font-bold mb-2">
                                            Category
                                        </label>
                                        <select
                                            value={filterData.category_id}
                                            onChange={e => setFilterData('category_id', e.target.value)}
                                            className="w-full border rounded px-3 py-2"
                                        >
                                            <option value="">All Categories</option>
                                            {categories.map(category => (
                                                <option key={category.id} value={category.id}>
                                                    {category.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label className="block text-gray-700 text-sm font-bold mb-2">
                                            Type
                                        </label>
                                        <select
                                            value={filterData.type}
                                            onChange={e => setFilterData('type', e.target.value)}
                                            className="w-full border rounded px-3 py-2"
                                        >
                                            <option value="">All Types</option>
                                            <option value="expense">Expense</option>
                                            <option value="income">Income</option>
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label className="block text-gray-700 text-sm font-bold mb-2">
                                            Search
                                        </label>
                                        <input
                                            type="text"
                                            value={filterData.search}
                                            onChange={e => setFilterData('search', e.target.value)}
                                            placeholder="Search in description"
                                            className="w-full border rounded px-3 py-2"
                                        />
                                    </div>
                                    
                                    <div>
                                        <label className="block text-gray-700 text-sm font-bold mb-2">
                                            From Date
                                        </label>
                                        <input
                                            type="date"
                                            value={filterData.date_from}
                                            onChange={e => setFilterData('date_from', e.target.value)}
                                            className="w-full border rounded px-3 py-2"
                                        />
                                    </div>
                                    
                                    <div>
                                        <label className="block text-gray-700 text-sm font-bold mb-2">
                                            To Date
                                        </label>
                                        <input
                                            type="date"
                                            value={filterData.date_to}
                                            onChange={e => setFilterData('date_to', e.target.value)}
                                            className="w-full border rounded px-3 py-2"
                                        />
                                    </div>
                                    
                                    <div className="flex space-x-2">
                                        <div className="flex-1">
                                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                                Min Amount
                                            </label>
                                            <input
                                                type="number"
                                                step="1"
                                                value={filterData.amount_min}
                                                onChange={e => setFilterData('amount_min', e.target.value)}
                                                className="w-full border rounded px-3 py-2"
                                            />
                                        </div>
                                        <div className="flex-1">
                                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                                Max Amount
                                            </label>
                                            <input
                                                type="number"
                                                step="1"
                                                value={filterData.amount_max}
                                                onChange={e => setFilterData('amount_max', e.target.value)}
                                                className="w-full border rounded px-3 py-2"
                                            />
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="mt-4 flex justify-end">
                                    <button
                                        type="button"
                                        onClick={resetFilters}
                                        className="mr-2 bg-gray-300 text-gray-700 px-4 py-2 rounded"
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="submit"
                                        disabled={filterProcessing}
                                        className="bg-blue-500 text-white px-4 py-2 rounded"
                                    >
                                        Apply Filters
                                    </button>
                                </div>
                            </form>
                        </div>
                    )}

                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6">
                            <div className="overflow-x-auto">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead>
                                        <tr>
                                            <th 
                                                className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                                                onClick={() => handleSort('date')}
                                            >
                                                Date {getSortIcon('date')}
                                            </th>
                                            <th 
                                                className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                                                onClick={() => handleSort('category_id')}
                                            >
                                                Category {getSortIcon('category_id')}
                                            </th>
                                            <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                                            <th 
                                                className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                                                onClick={() => handleSort('type')}
                                            >
                                                Type {getSortIcon('type')}
                                            </th>
                                            <th 
                                                className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                                                onClick={() => handleSort('amount')}
                                            >
                                                Amount {getSortIcon('amount')}
                                            </th>
                                            <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">
                                        {transactions.data.map((transaction) => (
                                            <tr key={transaction.id}>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{new Date(transaction.date).toLocaleDateString()}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{transaction.category.name}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{transaction.description}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                    <span className={`px-2 py-1 rounded-full text-xs ${transaction.type === 'income' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                        {transaction.type}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">₹{transaction.amount}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                    <div className="flex space-x-2">
                                                        <Link
                                                            href={route('transactions.show', transaction.id)}
                                                            className="text-blue-600 hover:text-blue-900"
                                                        >
                                                            View
                                                        </Link>
                                                        <Link
                                                            href={route('transactions.edit', transaction.id)}
                                                            className="text-yellow-600 hover:text-yellow-900"
                                                        >
                                                            Edit
                                                        </Link>
                                                        <Link
                                                            href={route('transactions.destroy', transaction.id)}
                                                            method="delete"
                                                            as="button"
                                                            className="text-red-600 hover:text-red-900"
                                                            onClick={(e) => {
                                                                if (!confirm('Are you sure you want to delete this transaction?')) {
                                                                    e.preventDefault();
                                                                }
                                                            }}
                                                        >
                                                            Delete
                                                        </Link>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                            
                            {transactions.data.length === 0 && (
                                <div className="text-center py-4">
                                    <p className="text-gray-500">No transactions found</p>
                                </div>
                            )}
                            
                            {transactions.links && transactions.links.length > 3 && (
                                <div className="mt-4">
                                    <div className="flex flex-wrap justify-center">
                                        {transactions.links.map((link, i) => (
                                            <Link
                                                key={i}
                                                href={link.url}
                                                className={`px-4 py-2 mx-1 rounded ${
                                                    link.active
                                                        ? 'bg-blue-500 text-white'
                                                        : 'bg-white text-blue-500 hover:bg-blue-100'
                                                } ${!link.url ? 'opacity-50 cursor-not-allowed' : ''}`}
                                                preserveScroll
                                            >
                                                {link.label.replace('&laquo;', '«').replace('&raquo;', '»')}
                                            </Link>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white p-6 rounded-lg w-full max-w-md">
                        <h3 className="text-lg font-semibold mb-4">Add Transaction</h3>
                        <form onSubmit={handleSubmit}>
                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Category
                                </label>
                                <select
                                    value={data.category_id}
                                    onChange={e => setData('category_id', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                >
                                    <option value="">Select a category</option>
                                    {categories.map(category => (
                                        <option key={category.id} value={category.id}>
                                            {category.name}
                                        </option>
                                    ))}
                                </select>
                                {errors.category_id && <p className="text-red-500 text-xs mt-1">{errors.category_id}</p>}
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Amount
                                </label>
                                <input
                                    type="number"
                                    step="1"
                                    value={data.amount}
                                    onChange={e => setData('amount', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                />
                                {errors.amount && <p className="text-red-500 text-xs mt-1">{errors.amount}</p>}
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Type
                                </label>
                                <select
                                    value={data.type}
                                    onChange={e => setData('type', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                >
                                    <option value="expense">Expense</option>
                                    <option value="income">Income</option>
                                </select>
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Date
                                </label>
                                <input
                                    type="date"
                                    value={data.date}
                                    onChange={e => setData('date', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                />
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Description
                                </label>
                                <textarea
                                    value={data.description}
                                    onChange={e => setData('description', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                />
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Attachment
                                </label>
                                <input
                                    type="file"
                                    onChange={e => setData('attachment', e.target.files[0])}
                                    className="w-full border rounded px-3 py-2"
                                />
                            </div>

                            <div className="flex justify-end gap-4">
                                <button
                                    type="button"
                                    onClick={() => setIsModalOpen(false)}
                                    className="bg-gray-300 text-gray-700 px-4 py-2 rounded"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={processing}
                                    className="bg-blue-500 text-white px-4 py-2 rounded"
                                >
                                    Save
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </AuthenticatedLayout>
    );
}
