import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, Link } from '@inertiajs/react';
import { useEffect } from 'react';

export default function Edit({ auth, budget, categories }) {
    const { data, setData, patch, processing, errors } = useForm({
        category_id: budget.category_id,
        amount: budget.amount,
        period: budget.period,
        start_date: budget.start_date,
        end_date: budget.end_date
    });

    // Calculate end date based on period and start date
    useEffect(() => {
        if (data.start_date && data.period) {
            const startDate = new Date(data.start_date);
            let endDate = new Date(startDate);
            
            if (data.period === 'monthly') {
                endDate.setMonth(startDate.getMonth() + 1);
            } else if (data.period === 'quarterly') {
                endDate.setMonth(startDate.getMonth() + 3);
            } else if (data.period === 'yearly') {
                endDate.setFullYear(startDate.getFullYear() + 1);
            }
            
            // Subtract one day to get the end of the period
            endDate.setDate(endDate.getDate() - 1);
            
            setData('end_date', endDate.toISOString().split('T')[0]);
        }
    }, [data.start_date, data.period]);

    const handleSubmit = (e) => {
        e.preventDefault();
        patch(route('budgets.update', budget.id), {
            preserveScroll: true,
        });
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Edit Budget</h2>}
        >
            <Head title="Edit Budget" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="mb-6">
                        <Link
                            href={route('budgets.index')}
                            className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600"
                        >
                            Back to Budgets
                        </Link>
                    </div>

                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6">
                            <form onSubmit={handleSubmit}>
                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Category
                                    </label>
                                    <select
                                        value={data.category_id}
                                        onChange={e => setData('category_id', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    >
                                        <option value="">Select a category</option>
                                        {categories.map(category => (
                                            <option key={category.id} value={category.id}>
                                                {category.name}
                                            </option>
                                        ))}
                                    </select>
                                    {errors.category_id && <p className="text-red-500 text-xs mt-1">{errors.category_id}</p>}
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Amount
                                    </label>
                                    <input
                                        type="number"
                                        step="1"
                                        value={data.amount}
                                        onChange={e => setData('amount', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    />
                                    {errors.amount && <p className="text-red-500 text-xs mt-1">{errors.amount}</p>}
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Period
                                    </label>
                                    <select
                                        value={data.period}
                                        onChange={e => setData('period', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    >
                                        <option value="monthly">Monthly</option>
                                        <option value="quarterly">Quarterly</option>
                                        <option value="yearly">Yearly</option>
                                    </select>
                                    {errors.period && <p className="text-red-500 text-xs mt-1">{errors.period}</p>}
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        Start Date
                                    </label>
                                    <input
                                        type="date"
                                        value={data.start_date}
                                        onChange={e => setData('start_date', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                    />
                                    {errors.start_date && <p className="text-red-500 text-xs mt-1">{errors.start_date}</p>}
                                </div>

                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">
                                        End Date
                                    </label>
                                    <input
                                        type="date"
                                        value={data.end_date}
                                        onChange={e => setData('end_date', e.target.value)}
                                        className="w-full border rounded px-3 py-2"
                                        readOnly
                                    />
                                    <p className="text-xs text-gray-500 mt-1">End date is calculated automatically based on period</p>
                                    {errors.end_date && <p className="text-red-500 text-xs mt-1">{errors.end_date}</p>}
                                </div>

                                <div className="flex justify-end">
                                    <button
                                        type="submit"
                                        disabled={processing}
                                        className="bg-blue-500 text-white px-4 py-2 rounded"
                                    >
                                        Update Budget
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}