import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';

export default function Show({ auth, budget, transactions, stats }) {
    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Budget Details</h2>}
        >
            <Head title="Budget Details" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="mb-6 flex justify-between">
                        <Link
                            href={route('budgets.index')}
                            className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600"
                        >
                            Back to Budgets
                        </Link>
                        <div className="flex space-x-2">
                            <Link
                                href={route('budgets.edit', budget.id)}
                                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600"
                            >
                                Edit
                            </Link>
                            <Link
                                href={route('budgets.destroy', budget.id)}
                                method="delete"
                                as="button"
                                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600"
                                onClick={(e) => {
                                    if (!confirm('Are you sure you want to delete this budget?')) {
                                        e.preventDefault();
                                    }
                                }}
                            >
                                Delete
                            </Link>
                        </div>
                    </div>

                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                        <div className="p-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <h3 className="text-2xl font-bold">{budget.category.name} Budget</h3>
                                    <p className="text-gray-600 mt-1">
                                        {budget.period.charAt(0).toUpperCase() + budget.period.slice(1)} Budget
                                    </p>
                                    <div className="mt-4">
                                        <p className="text-gray-600">Period</p>
                                        <p className="font-medium">
                                            {new Date(budget.start_date).toLocaleDateString()} - {new Date(budget.end_date).toLocaleDateString()}
                                        </p>
                                    </div>
                                    <div className="mt-4">
                                        <p className="text-gray-600">Budget Amount</p>
                                        <p className="text-2xl font-bold">₹{budget.amount}</p>
                                    </div>
                                </div>

                                <div>
                                    <div className="bg-gray-50 p-4 rounded-lg">
                                        <h4 className="text-lg font-semibold mb-4">Budget Progress</h4>
                                        <div className="mb-2 flex justify-between">
                                            <span>₹{stats.spent} spent of ₹{budget.amount}</span>
                                            <span className={`font-medium ${
                                                stats.status === 'over_budget' ? 'text-red-600' : 
                                                stats.status === 'warning' ? 'text-yellow-600' : 'text-green-600'
                                            }`}>
                                                {stats.progress}%
                                            </span>
                                        </div>
                                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                                            <div
                                                className={`h-2.5 rounded-full ${
                                                    stats.status === 'over_budget' ? 'bg-red-600' : 
                                                    stats.status === 'warning' ? 'bg-yellow-500' : 'bg-green-600'
                                                }`}
                                                style={{ width: `${stats.progress}%` }}
                                            ></div>
                                        </div>
                                        <div className="mt-4 grid grid-cols-2 gap-4">
                                            <div>
                                                <p className="text-gray-500 text-sm">Spent</p>
                                                <p className="text-xl font-bold">₹{stats.spent}</p>
                                            </div>
                                            <div>
                                                <p className="text-gray-500 text-sm">Remaining</p>
                                                <p className="text-xl font-bold">₹{stats.remaining}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6">
                            <h3 className="text-lg font-semibold mb-4">Transactions</h3>
                            {transactions.length > 0 ? (
                                <div className="overflow-x-auto">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead>
                                            <tr>
                                                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                                                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-200">
                                            {transactions.map((transaction) => (
                                                <tr key={transaction.id}>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                        {new Date(transaction.date).toLocaleDateString()}
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                        {transaction.description || 'No description'}
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                        ₹{transaction.amount}
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                        <Link
                                                            href={route('transactions.show', transaction.id)}
                                                            className="text-blue-600 hover:text-blue-900"
                                                        >
                                                            View
                                                        </Link>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            ) : (
                                <div className="text-center py-4">
                                    <p className="text-gray-500">No transactions found for this budget period</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}