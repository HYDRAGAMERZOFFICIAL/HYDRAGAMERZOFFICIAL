import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, Link, router as Inertia } from '@inertiajs/react';
import { useState, useEffect } from 'react';

export default function Budgets({ auth, budgets, categories, filters = {}, stats }) {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isFilterOpen, setIsFilterOpen] = useState(false);
    
    const { data, setData, post, processing, errors, reset } = useForm({
        category_id: '',
        amount: '',
        period: 'monthly',
        start_date: new Date().toISOString().split('T')[0],
        end_date: ''
    });
    
    const { data: filterData, setData: setFilterData, get: applyFilter, processing: filterProcessing } = useForm({
        category_id: filters.category_id || '',
        period: filters.period || '',
        status: filters.status || '',
        sort_field: filters.sort_field || 'start_date',
        sort_direction: filters.sort_direction || 'desc'
    });
    
    // Calculate end date based on period and start date
    useEffect(() => {
        if (data.start_date && data.period) {
            const startDate = new Date(data.start_date);
            let endDate = new Date(startDate);
            
            if (data.period === 'monthly') {
                endDate.setMonth(startDate.getMonth() + 1);
            } else if (data.period === 'quarterly') {
                endDate.setMonth(startDate.getMonth() + 3);
            } else if (data.period === 'yearly') {
                endDate.setFullYear(startDate.getFullYear() + 1);
            }
            
            // Subtract one day to get the end of the period
            endDate.setDate(endDate.getDate() - 1);
            
            setData('end_date', endDate.toISOString().split('T')[0]);
        }
    }, [data.start_date, data.period]);

    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('budgets.store'), {
            onSuccess: () => {
                reset();
                setIsModalOpen(false);
            }
        });
    };
    
    const handleFilterSubmit = (e) => {
        e.preventDefault();
        applyFilter(route('budgets.index'), {
            preserveState: true,
            preserveScroll: true,
            onSuccess: () => {
                setIsFilterOpen(false);
            }
        });
    };
    
    const resetFilters = () => {
        // Create a clean filter object
        const resetFilterData = {
            category_id: '',
            period: '',
            status: '',
            sort_field: 'start_date',
            sort_direction: 'desc'
        };
        
        // Update the local state
        setFilterData(resetFilterData);
        
        // Force a hard reload to ensure all filters are cleared
        Inertia.visit(route('budgets.index'), {
            method: 'get',
            data: resetFilterData,
            preserveScroll: true,
            onSuccess: () => {
                setIsFilterOpen(false);
            },
            // Force a fresh page load
            preserveState: false,
            replace: true
        });
    };
    
    const handleSort = (field) => {
        const direction = 
            filterData.sort_field === field && filterData.sort_direction === 'asc' 
                ? 'desc' 
                : 'asc';
                
        setFilterData({
            ...filterData,
            sort_field: field,
            sort_direction: direction
        });
        
        applyFilter(route('budgets.index'), {
            preserveState: true,
            preserveScroll: true
        });
    };
    
    const getStatusColor = (budget) => {
        const progress = budget.amount > 0 ? Math.min(100, Math.round((budget.spent / budget.amount) * 100)) : 0;
        
        if (progress >= 100) {
            return 'bg-red-600';
        } else if (progress >= 80) {
            return 'bg-yellow-500';
        } else {
            return 'bg-green-600';
        }
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Budgets</h2>}
        >
            <Head title="Budgets" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="mb-6 flex justify-between">
                        <div className="flex space-x-2">
                            <button
                                onClick={() => setIsModalOpen(true)}
                                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600"
                            >
                                Add Budget
                            </button>
                            <button
                                onClick={() => setIsFilterOpen(!isFilterOpen)}
                                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300"
                            >
                                {isFilterOpen ? 'Hide Filters' : 'Show Filters'}
                            </button>
                        </div>
                        
                        {Object.values(filterData).some(value => value !== '' && value !== 'start_date' && value !== 'desc') && (
                            <button
                                onClick={resetFilters}
                                className="text-gray-600 hover:text-gray-900"
                            >
                                Clear Filters
                            </button>
                        )}
                    </div>
                    
                    {isFilterOpen && (
                        <div className="mb-6 bg-white p-4 rounded-lg shadow">
                            <h3 className="text-lg font-semibold mb-4">Filter Budgets</h3>
                            <form onSubmit={handleFilterSubmit}>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <label className="block text-gray-700 text-sm font-bold mb-2">
                                            Category
                                        </label>
                                        <select
                                            value={filterData.category_id}
                                            onChange={e => setFilterData('category_id', e.target.value)}
                                            className="w-full border rounded px-3 py-2"
                                        >
                                            <option value="">All Categories</option>
                                            {categories.map(category => (
                                                <option key={category.id} value={category.id}>
                                                    {category.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label className="block text-gray-700 text-sm font-bold mb-2">
                                            Period
                                        </label>
                                        <select
                                            value={filterData.period}
                                            onChange={e => setFilterData('period', e.target.value)}
                                            className="w-full border rounded px-3 py-2"
                                        >
                                            <option value="">All Periods</option>
                                            <option value="monthly">Monthly</option>
                                            <option value="quarterly">Quarterly</option>
                                            <option value="yearly">Yearly</option>
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label className="block text-gray-700 text-sm font-bold mb-2">
                                            Status
                                        </label>
                                        <select
                                            value={filterData.status}
                                            onChange={e => setFilterData('status', e.target.value)}
                                            className="w-full border rounded px-3 py-2"
                                        >
                                            <option value="">All Statuses</option>
                                            <option value="active">Active</option>
                                            <option value="over_budget">Over Budget</option>
                                            <option value="warning">Warning</option>
                                            <option value="on_track">On Track</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div className="mt-4 flex justify-end">
                                    <button
                                        type="button"
                                        onClick={resetFilters}
                                        className="mr-2 bg-gray-300 text-gray-700 px-4 py-2 rounded"
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="submit"
                                        disabled={filterProcessing}
                                        className="bg-blue-500 text-white px-4 py-2 rounded"
                                    >
                                        Apply Filters
                                    </button>
                                </div>
                            </form>
                        </div>
                    )}
                    
                    {/* Budget Stats */}
                    <div className="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="bg-white p-4 rounded-lg shadow">
                            <p className="text-gray-500 text-sm">Total Budgeted</p>
                            <p className="text-2xl font-bold">₹{stats.totalBudgeted}</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow">
                            <p className="text-gray-500 text-sm">Total Spent</p>
                            <p className="text-2xl font-bold">₹{stats.totalSpent}</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow">
                            <p className="text-gray-500 text-sm">Overall Progress</p>
                            <div className="flex items-center">
                                <p className="text-2xl font-bold">{stats.overallProgress}%</p>
                                <div className="ml-2 flex-grow">
                                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                                        <div
                                            className={`h-2.5 rounded-full ${
                                                stats.overallProgress >= 100 ? 'bg-red-600' : 
                                                stats.overallProgress >= 80 ? 'bg-yellow-500' : 'bg-green-600'
                                            }`}
                                            style={{ width: `${stats.overallProgress}%` }}
                                        ></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow">
                            <p className="text-gray-500 text-sm">Budget Status</p>
                            <div className="flex space-x-2 mt-2">
                                <div className="flex items-center">
                                    <div className="w-3 h-3 rounded-full bg-red-600 mr-1"></div>
                                    <span className="text-sm">{stats.overBudgetCount} Over</span>
                                </div>
                                <div className="flex items-center">
                                    <div className="w-3 h-3 rounded-full bg-yellow-500 mr-1"></div>
                                    <span className="text-sm">{stats.warningCount} Warning</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {budgets.map((budget) => (
                                    <div key={budget.id} className="border rounded-lg p-4 relative">
                                        <div className="absolute top-2 right-2 flex space-x-2">
                                            <Link
                                                href={route('budgets.edit', budget.id)}
                                                className="text-gray-500 hover:text-gray-700"
                                            >
                                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                                </svg>
                                            </Link>
                                            <Link
                                                href={route('budgets.destroy', budget.id)}
                                                method="delete"
                                                as="button"
                                                className="text-red-500 hover:text-red-700"
                                                onClick={(e) => {
                                                    if (!confirm('Are you sure you want to delete this budget?')) {
                                                        e.preventDefault();
                                                    }
                                                }}
                                            >
                                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                </svg>
                                            </Link>
                                        </div>
                                        
                                        <Link href={route('budgets.show', budget.id)}>
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <h3 className="text-lg font-semibold">{budget.category.name}</h3>
                                                    <p className="text-sm text-gray-600">
                                                        {budget.period.charAt(0).toUpperCase() + budget.period.slice(1)}
                                                    </p>
                                                </div>
                                                <div className="text-right">
                                                    <p className="text-2xl font-bold">₹{budget.amount}</p>
                                                    <p className="text-sm text-gray-600">
                                                        {new Date(budget.start_date).toLocaleDateString()} - {new Date(budget.end_date).toLocaleDateString()}
                                                    </p>
                                                </div>
                                            </div>
                                            <div className="mt-4">
                                                <div className="mb-1 flex justify-between">
                                                    <span className="text-sm text-gray-600">₹{budget.spent} spent</span>
                                                    <span className="text-sm font-medium">
                                                        {budget.progress}%
                                                    </span>
                                                </div>
                                                <div className="w-full bg-gray-200 rounded-full h-2.5">
                                                    <div
                                                        className={`h-2.5 rounded-full ${getStatusColor(budget)}`}
                                                        style={{ width: `${budget.progress}%` }}
                                                    ></div>
                                                </div>
                                                <div className="mt-2 flex justify-between text-sm">
                                                    <span>₹{budget.remaining} remaining</span>
                                                    {new Date() >= new Date(budget.start_date) && new Date() <= new Date(budget.end_date) && (
                                                        <span className="font-medium">Active</span>
                                                    )}
                                                </div>
                                            </div>
                                        </Link>
                                    </div>
                                ))}
                            </div>
                            
                            {budgets.length === 0 && (
                                <div className="text-center py-4">
                                    <p className="text-gray-500">No budgets found</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white p-6 rounded-lg w-full max-w-md">
                        <h3 className="text-lg font-semibold mb-4">Add Budget</h3>
                        <form onSubmit={handleSubmit}>
                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Category
                                </label>
                                <select
                                    value={data.category_id}
                                    onChange={e => setData('category_id', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                >
                                    <option value="">Select a category</option>
                                    {categories.map(category => (
                                        <option key={category.id} value={category.id}>
                                            {category.name}
                                        </option>
                                    ))}
                                </select>
                                {errors.category_id && <p className="text-red-500 text-xs mt-1">{errors.category_id}</p>}
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Amount
                                </label>
                                <input
                                    type="number"
                                    step="1"
                                    value={data.amount}
                                    onChange={e => setData('amount', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                />
                                {errors.amount && <p className="text-red-500 text-xs mt-1">{errors.amount}</p>}
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Period
                                </label>
                                <select
                                    value={data.period}
                                    onChange={e => setData('period', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                >
                                    <option value="monthly">Monthly</option>
                                    <option value="quarterly">Quarterly</option>
                                    <option value="yearly">Yearly</option>
                                </select>
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    Start Date
                                </label>
                                <input
                                    type="date"
                                    value={data.start_date}
                                    onChange={e => setData('start_date', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                />
                            </div>

                            <div className="mb-4">
                                <label className="block text-gray-700 text-sm font-bold mb-2">
                                    End Date
                                </label>
                                <input
                                    type="date"
                                    value={data.end_date}
                                    onChange={e => setData('end_date', e.target.value)}
                                    className="w-full border rounded px-3 py-2"
                                    readOnly
                                />
                                <p className="text-xs text-gray-500 mt-1">End date is calculated automatically based on period</p>
                            </div>

                            <div className="flex justify-end gap-4">
                                <button
                                    type="button"
                                    onClick={() => setIsModalOpen(false)}
                                    className="bg-gray-300 text-gray-700 px-4 py-2 rounded"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={processing}
                                    className="bg-blue-500 text-white px-4 py-2 rounded"
                                >
                                    Save
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </AuthenticatedLayout>
    );
}
