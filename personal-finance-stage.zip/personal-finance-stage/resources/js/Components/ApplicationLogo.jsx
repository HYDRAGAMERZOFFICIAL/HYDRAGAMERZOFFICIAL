export default function ApplicationLogo({ className = '', ...props }) {
    return (
        <div className={`flex items-center ${className}`} {...props}>
            <img
                src="/images/pfc_logo.png"
                alt="Pera Fin Core"
                className="w-10 h-10"
            />
            <span className="ml-2 text-2xl font-bold text-blue-900">PERA FIN CORE</span>
        </div>
    );
}
