php artisan migrate --env=testing
php artisan db:seed --env=testing

To perform phpunit test follow the mentioned steps :-

    1. Install composer php unit tests

        composer require --dev phpunit/phpunit 

    2. Checking the version of the phpunit

        php artisan ./vendor/bin/phpunit --version

    3. After the installation and create a new file to write the test cases

        php artisan make:test LogicTest

    4. To run the test cases

        php artisan test tests/feature/LogicTest.php

Test cases :-

    1. successful test

           PASS  Tests\Feature\LogicTest
            ✓ example                                                          0.35s
            ✓ categories                                                       0.02s
            ✓ addition                                                         0.02s

            Tests:    3 passed (3 assertions)
            Duration: 0.68s

    2. Failed test

               FAIL  Tests\Feature\LogicTest
                ✓ example                                                          0.40s
                ✓ categories                                                       0.03s
                ⨯ addition                                                         0.05s
                ────────────────────────────────────────────────────────────────────────
                FAILED  Tests\Feature\LogicTest > addition
                Failed asserting that 5 matches expected 4.

                at tests\Feature\LogicTest.php:32
                    28▕     {
                    29▕         $result = $this->add(2,3);
                    30▕         $expected = 4;
                    31▕
                ➜  32▕         $this->assertEquals($expected, $result);
                    33▕     }
                    34▕
                    35▕     private function add(int $num1, int $num2){
                    36▕         return $num1+$num2;

                1   tests\Feature\LogicTest.php:32

                Tests:    1 failed, 2 passed (3 assertions)
                Duration: 0.75s

Test case writing :-

    1. create a file in test/feature to write all the test cases 
        // one file can have multiple test cases written in it 
        
        Example of test case 

                public function test_example(): void
                {
                    $response = $this->get('/');
                    $response->assertStatus(200);
                }

    // User can write any test case from the files and create there own test cases as well 

    2. To test the functionality for the api the user must write test case using 
        -> controllers 
        -> models 
        -> test case statement

        Example 

            use App\Models\User;

            public function test_category_with200sucess(): void
            {
                $user = User::factory()->create();
                $response = $this
                    ->actingAs($user)
                    ->get('/categories');
                $response->assertStatus(200);
            }