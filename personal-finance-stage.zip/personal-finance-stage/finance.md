# PERA FIN CORE Finance - Budgeting Module Documentation

## Overview

The budgeting module in PERA FIN CORE allows users to set spending limits for specific expense categories over defined time periods. The system tracks spending against these budgets and provides visual feedback on budget progress, helping users manage their finances more effectively.

## Core Components

### 1. Budget Model

The `Budget` model is the central component of the budgeting system with the following key attributes:

- **user_id**: Links the budget to a specific user
- **category_id**: Associates the budget with a specific expense category
- **amount**: The maximum amount allocated for this budget
- **period**: The time frame for the budget (monthly, quarterly, yearly)
- **start_date**: When the budget period begins
- **end_date**: When the budget period ends

### 2. Relationships

The budgeting system relies on relationships between several models:

- **Budget belongs to User**: Each budget is owned by a specific user
- **Budget belongs to Category**: Each budget is associated with a specific expense category
- **Category has many Budgets**: A category can have multiple budgets (for different time periods)
- **User has many Budgets**: A user can create multiple budgets
- **Transaction belongs to Category**: Transactions are categorized, which links them to budgets

### 3. Budget Calculations

The system performs several key calculations to track budget progress:

#### Spent Amount

```php
public function getSpentAttribute()
{
    return $this->user->transactions()
        ->where('category_id', $this->category_id)
        ->where('type', 'expense')
        ->whereBetween('date', [$this->start_date, $this->end_date])
        ->sum('amount');
}
```

This calculates the total amount spent in the budget's category during the budget period by:
1. Finding all transactions belonging to the user
2. Filtering for the specific category
3. Ensuring they are expense transactions (not income)
4. Limiting to transactions within the budget's date range
5. Summing the amounts

#### Remaining Amount

```php
public function getRemainingAttribute()
{
    return max(0, $this->amount - $this->getSpentAttribute());
}
```

This calculates how much of the budget is left by subtracting the spent amount from the total budget amount, with a minimum of zero.

#### Progress Percentage

```php
public function getProgressAttribute()
{
    if ($this->amount <= 0) {
        return 0;
    }

    $progress = ($this->getSpentAttribute() / $this->amount) * 100;
    return min(100, round($progress, 1));
}
```

This calculates the percentage of the budget that has been used by:
1. Dividing the spent amount by the total budget amount
2. Multiplying by 100 to get a percentage
3. Rounding to 1 decimal place
4. Capping at 100% (even if overspent)

#### Budget Status

```php
public function getStatusAttribute()
{
    $progress = $this->getProgressAttribute();

    if ($progress >= 100) {
        return 'over_budget';
    } elseif ($progress >= 80) {
        return 'warning';
    } else {
        return 'on_track';
    }
}
```

This determines the status of the budget based on the progress percentage:
- **on_track**: Less than 80% of the budget has been used
- **warning**: Between 80% and 100% of the budget has been used
- **over_budget**: More than 100% of the budget has been used

#### Daily Average Spending

```php
public function getDailyAverage()
{
    $spent = $this->getSpentAttribute();
    $daysElapsed = $this->start_date->diffInDays(now()) + 1;

    return $daysElapsed > 0 ? round($spent / $daysElapsed, 2) : 0;
}
```

This calculates the average daily spending for this budget by dividing the total spent by the number of days elapsed since the budget started.

#### Projected Spending

```php
public function getProjectedSpending()
{
    $dailyAverage = $this->getDailyAverage();
    $totalDays = $this->start_date->diffInDays($this->end_date) + 1;

    return round($dailyAverage * $totalDays, 2);
}
```

This estimates the total spending by the end of the budget period based on the current daily average spending rate.

#### Recommended Daily Spending

```php
public function getRecommendedDailySpending()
{
    $remaining = $this->getRemainingAttribute();
    $daysLeft = now()->diffInDays($this->end_date) + 1;

    return $daysLeft > 0 ? round($remaining / $daysLeft, 2) : 0;
}
```

This calculates how much a user should spend per day for the remainder of the budget period to stay within the budget limit.

#### Normalized Amount

```php
public function getNormalizedAmount()
{
    $totalDays = $this->start_date->diffInDays($this->end_date) + 1;
    $daysElapsed = min($totalDays, $this->start_date->diffInDays(now()) + 1);

    $normalizedAmount = ($this->amount / $totalDays) * $daysElapsed;
    return round($normalizedAmount, 2);
}
```

This calculates a pro-rated budget amount based on how far into the budget period we are, which is useful for comparing budgets with different periods or evaluating budget performance mid-period.

#### Spending Pace Status

```php
public function getSpendingPaceStatus()
{
    $spent = $this->getSpentAttribute();
    $expected = $this->getExpectedSpendingToDate();

    $difference = $spent - $expected;
    $threshold = $expected * 0.1; // 10% threshold

    if (abs($difference) <= $threshold) {
        return 'on_track';
    } elseif ($difference > $threshold) {
        return 'ahead';
    } else {
        return 'behind';
    }
}
```

This determines if the user is spending at a rate that is on track, ahead, or behind the expected pace based on an even distribution of the budget over time.

## Example Usage

### Creating a Monthly Food Budget

Let's say a user wants to create a monthly budget of $500 for food expenses:

1. The user selects the "Food" category from their expense categories
2. They set the amount to $500
3. They select "monthly" as the period
4. They set the start date to the first day of the month
5. They set the end date to the last day of the month

```php
$budget = new Budget([
    'user_id' => $user->id,
    'category_id' => $foodCategory->id,
    'amount' => 500.00,
    'period' => 'monthly',
    'start_date' => '2023-06-01',
    'end_date' => '2023-06-30'
]);
$budget->save();
```

### Tracking Spending Against the Budget

When the user adds food-related expenses:

1. They create a transaction with the "Food" category
2. The transaction amount is automatically counted toward the food budget
3. The budget progress is updated

```php
$transaction = new Transaction([
    'user_id' => $user->id,
    'category_id' => $foodCategory->id,
    'amount' => 75.50,
    'type' => 'expense',
    'date' => '2023-06-15',
    'description' => 'Grocery shopping'
]);
$transaction->save();
```

After this transaction:
- The spent amount for the food budget would increase by $75.50
- If this was the first food expense of the month, the budget progress would be 15.1% ($75.50 / $500.00 * 100)
- The remaining amount would be $424.50 ($500.00 - $75.50)
- The status would be "on_track" since the progress is below 80%
- The daily average would be calculated based on the days elapsed since June 1
- The projected spending would estimate the total spending by June 30 based on the current rate

### Budget Visualization

The system provides several ways to visualize budget progress:

1. **Progress Bar**: Shows the percentage of the budget that has been used
2. **Daily Spending Chart**: Shows spending patterns over time
3. **Cumulative Spending vs. Ideal Line**: Compares actual spending to an even distribution

### Budget Alerts

The system alerts users when they approach or exceed their budget limits:

1. **Warning Alert**: When a budget reaches 80% or more of its limit
   ```php
   if ($budget->status === 'warning') {
       // Show warning notification
   }
   ```

2. **Over Budget Alert**: When spending exceeds the budget
   ```php
   if ($budget->status === 'over_budget') {
       // Show alert notification
   }
   ```

## Dashboard Integration

The dashboard displays budget information to give users a quick overview of their financial status:

1. **Active Budgets Count**: Number of currently active budgets
2. **Over Budget Count**: Number of budgets where spending has exceeded the limit
3. **Warning Count**: Number of budgets at 80% or more of their limit
4. **Top Budgets**: The budgets with the highest progress percentage

This information helps users quickly identify areas where they need to adjust their spending.

## Budget Validation

The system enforces several validation rules for budgets:

1. The category must exist and belong to the user
2. The budget amount must be a positive number
3. The period must be one of the allowed values (monthly, quarterly, yearly)
4. The start date must be a valid date
5. The end date must be after the start date
6. Budgets for the same category cannot overlap in time periods

## Advanced Features

### Daily Spending Data

The system calculates daily spending data for each budget, which is used to generate charts:

```php
private function getDailySpendingData(Budget $budget)
{
    $startDate = $budget->start_date;
    $endDate = $budget->end_date;

    // Get daily spending
    $dailySpending = Transaction::where('user_id', auth()->id())
        ->where('category_id', $budget->category_id)
        ->where('type', 'expense')
        ->whereBetween('date', [$startDate, $endDate])
        ->select(DB::raw('DATE(date) as day'), DB::raw('SUM(amount) as total'))
        ->groupBy('day')
        ->get()
        ->keyBy('day')
        ->map(function ($item) {
            return round($item->total, 2);
        });

    // Create a complete date range with zeros for days without spending
    $dateRange = [];
    $currentDate = clone $startDate;

    while ($currentDate->lte($endDate)) {
        $dateKey = $currentDate->format('Y-m-d');
        $dateRange[$dateKey] = $dailySpending[$dateKey] ?? 0;
        $currentDate->addDay();
    }

    // Calculate cumulative spending
    $cumulativeSpending = [];
    $runningTotal = 0;

    foreach ($dateRange as $date => $amount) {
        $runningTotal += $amount;
        $cumulativeSpending[$date] = round($runningTotal, 2);
    }

    // Calculate ideal spending line (even distribution)
    $idealSpending = [];
    $dailyBudget = $budget->amount / count($dateRange);
    $idealRunningTotal = 0;

    foreach ($dateRange as $date => $amount) {
        $idealRunningTotal += $dailyBudget;
        $idealSpending[$date] = round($idealRunningTotal, 2);
    }

    return [
        'dates' => array_keys($dateRange),
        'daily' => array_values($dateRange),
        'cumulative' => array_values($cumulativeSpending),
        'ideal' => array_values($idealSpending)
    ];
}
```

This data is used to create charts that show:
1. Daily spending amounts
2. Cumulative spending over time
3. Ideal spending line (even distribution)

### Budget Summary for Dashboard

The system provides a summary of budget information for the dashboard:

```php
public function summary()
{
    $user = auth()->user();
    $currentBudgets = $user->budgets()
        ->with('category')
        ->whereDate('start_date', '<=', now())
        ->whereDate('end_date', '>=', now())
        ->get();

    $overBudgetCount = $currentBudgets->filter(function($budget) {
        return $budget->isOverBudget();
    })->count();

    $warningCount = $currentBudgets->filter(function($budget) {
        return $budget->status === 'warning';
    })->count();

    return response()->json([
        'activeBudgets' => $currentBudgets->count(),
        'overBudgetCount' => $overBudgetCount,
        'warningCount' => $warningCount,
        'topBudgets' => $currentBudgets->sortByDesc('progress')->take(3)->values()
    ]);
}
```

## Conclusion

The budgeting module provides a comprehensive system for tracking and managing expenses against predefined limits. By linking budgets to categories and transactions, the system automatically calculates progress and provides valuable insights to help users maintain financial discipline.

The key strengths of this implementation are:

1. **Real-time Feedback**: Users get immediate feedback on their spending patterns
2. **Predictive Analysis**: The system projects future spending based on current rates
3. **Visual Representation**: Charts and progress bars make it easy to understand budget status
4. **Actionable Insights**: Recommended daily spending helps users adjust their behavior
5. **Flexible Periods**: Support for monthly, quarterly, and yearly budgets
6. **Category-Based**: Budgets are tied to expense categories for detailed tracking

This comprehensive approach to budgeting helps users make informed decisions about their finances before they exceed their planned limits, promoting better financial habits and reducing financial stress.