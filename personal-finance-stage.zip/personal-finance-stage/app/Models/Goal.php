<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Goal extends Model
{
    use HasFactory;
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'name',
        'description',
        'target_amount',
        'current_amount',
        'target_date',
        'status',
        'priority',
    ];
    
    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'target_date' => 'date',
        'target_amount' => 'integer',
        'current_amount' => 'integer',
    ];
    
    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = [
        'progress_percentage',
        'is_achieved',
        'remaining_amount',
    ];
    
    /**
     * Get the user that owns the goal.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    
    /**
     * Calculate the progress percentage of the goal.
     *
     * @return float
     */
    public function getProgressPercentageAttribute()
    {
        if ($this->target_amount <= 0) {
            return 0;
        }
        
        $percentage = ($this->current_amount / $this->target_amount) * 100;
        return min(100, round($percentage, 2));
    }
    
    /**
     * Check if the goal is achieved.
     *
     * @return bool
     */
    public function getIsAchievedAttribute()
    {
        return $this->current_amount >= $this->target_amount;
    }
    
    /**
     * Get the remaining amount to achieve the goal.
     *
     * @return float
     */
    public function getRemainingAmountAttribute()
    {
        $remaining = $this->target_amount - $this->current_amount;
        return max(0, $remaining);
    }
}
