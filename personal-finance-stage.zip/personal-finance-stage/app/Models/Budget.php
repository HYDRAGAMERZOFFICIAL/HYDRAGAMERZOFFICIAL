<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\User;
use App\Models\Category;
use App\Models\Transaction;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class Budget extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'category_id',
        'amount',
        'period',
        'start_date',
        'end_date'
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'amount' => 'integer'
    ];

    protected $appends = [
        'spent',
        'remaining',
        'progress',
        'status',
        'daily_average',
        'projected_spending',
        'recommended_daily',
        'spending_pace'
    ];

    /**
     * The "booted" method of the model.
     *
     * @return void
     */
    protected static function booted()
    {
        // Clear cache when a transaction is created, updated, or deleted
        Transaction::created(function ($transaction) {
            self::clearCacheForTransaction($transaction);
        });

        Transaction::updated(function ($transaction) {
            self::clearCacheForTransaction($transaction);
        });

        Transaction::deleted(function ($transaction) {
            self::clearCacheForTransaction($transaction);
        });
    }

    /**
     * Clear cache for budgets related to a transaction
     */
    protected static function clearCacheForTransaction($transaction)
    {
        if ($transaction->type === 'expense') {
            $cacheKey = "budget_spent_{$transaction->user_id}_{$transaction->category_id}";
            Cache::forget($cacheKey);
        }
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * Get the total amount spent for this budget's category within the budget period.
     *
     * @return float
     */
    public function getSpentAttribute()
    {
        $cacheKey = "budget_spent_{$this->user_id}_{$this->category_id}_{$this->id}";

        // Disable caching to ensure immediate updates
        return Cache::remember($cacheKey, now()->addSeconds(1), function () {
            return $this->user->transactions()
                ->where('category_id', $this->category_id)
                ->where('type', 'expense')
                ->whereBetween('date', [$this->start_date, $this->end_date])
                ->sum('amount');
        });
    }

    /**
     * Get the remaining amount for this budget.
     *
     * @return float
     */
    public function getRemainingAttribute()
    {
        return max(0, $this->amount - $this->spent);
    }

    /**
     * Get the progress percentage for this budget.
     *
     * @return float
     */
    public function getProgressAttribute()
    {
        if ($this->amount <= 0) {
            return 0;
        }

        $progress = ($this->spent / $this->amount) * 100;
        return min(100, round($progress, 1));
    }

    /**
     * Get the status of the budget (on_track, warning, over_budget).
     *
     * @return string
     */
    public function getStatusAttribute()
    {
        $progress = $this->progress;

        if ($progress >= 100) {
            return 'over_budget';
        } elseif ($progress >= 80) {
            return 'warning';
        } else {
            return 'on_track';
        }
    }

    /**
     * Check if the budget is over the limit.
     *
     * @return bool
     */
    public function isOverBudget()
    {
        return $this->spent > $this->amount;
    }

    /**
     * Get the daily average spending for this budget.
     *
     * @return float
     */
    public function getDailyAverageAttribute()
    {
        $spent = $this->spent;
        $today = Carbon::today();

        // If budget hasn't started yet, return 0
        if ($this->start_date->isAfter($today)) {
            return 0;
        }

        // Calculate days elapsed (use end date if it's in the past)
        $endDate = $this->end_date->isBefore($today) ? $this->end_date : $today;
        $daysElapsed = $this->start_date->diffInDays($endDate) + 1;

        return $daysElapsed > 0 ? round($spent / $daysElapsed, 2) : 0;
    }

    /**
     * Get the projected spending by the end of the budget period based on current rate.
     *
     * @return float
     */
    public function getProjectedSpendingAttribute()
    {
        $dailyAverage = $this->daily_average;
        $totalDays = $this->start_date->diffInDays($this->end_date) + 1;

        return round($dailyAverage * $totalDays, 2);
    }

    /**
     * Get the recommended daily spending to stay within budget.
     *
     * @return float
     */
    public function getRecommendedDailyAttribute()
    {
        $remaining = $this->remaining;
        $today = Carbon::today();

        // If budget is already over, return 0
        if ($this->end_date->isBefore($today)) {
            return 0;
        }

        $daysLeft = $today->diffInDays($this->end_date) + 1;

        return $daysLeft > 0 ? round($remaining / $daysLeft, 2) : 0;
    }

    /**
     * Get the normalized amount based on the current date and budget period.
     * This is useful for comparing budgets with different periods.
     *
     * @return float
     */
    public function getNormalizedAmount()
    {
        $totalDays = $this->start_date->diffInDays($this->end_date) + 1;
        $today = Carbon::today();

        // If budget hasn't started yet, return 0
        if ($this->start_date->isAfter($today)) {
            return 0;
        }

        // If budget is over, return full amount
        if ($this->end_date->isBefore($today)) {
            return $this->amount;
        }

        $daysElapsed = $this->start_date->diffInDays($today) + 1;
        $normalizedAmount = ($this->amount / $totalDays) * $daysElapsed;

        return round($normalizedAmount, 2);
    }

    /**
     * Get the expected spending up to today based on even distribution.
     *
     * @return float
     */
    public function getExpectedSpendingToDate()
    {
        return $this->getNormalizedAmount();
    }

    /**
     * Check if spending is ahead of, on track with, or behind the expected rate.
     *
     * @return string
     */
    public function getSpendingPaceAttribute()
    {
        $spent = $this->spent;
        $expected = $this->getExpectedSpendingToDate();

        // If expected is 0, avoid division by zero
        if ($expected <= 0) {
            return $spent > 0 ? 'ahead' : 'on_track';
        }

        $difference = $spent - $expected;
        $threshold = $expected * 0.1; // 10% threshold

        if (abs($difference) <= $threshold) {
            return 'on_track';
        } elseif ($difference > $threshold) {
            return 'ahead';
        } else {
            return 'behind';
        }
    }

    /**
     * Get spending by day of week for this budget.
     *
     * @return array
     */
    public function getSpendingByDayOfWeek()
    {
        $cacheKey = "budget_day_of_week_{$this->id}";

        return Cache::remember($cacheKey, now()->addHours(24), function () {
            $result = Transaction::where('user_id', $this->user_id)
                ->where('category_id', $this->category_id)
                ->where('type', 'expense')
                ->whereBetween('date', [$this->start_date, $this->end_date])
                ->select(DB::raw('DAYOFWEEK(date) as day_of_week'), DB::raw('SUM(amount) as total'))
                ->groupBy('day_of_week')
                ->orderBy('day_of_week')
                ->get();

            // Initialize all days with zero
            $days = [
                1 => ['name' => 'Sunday', 'total' => 0],
                2 => ['name' => 'Monday', 'total' => 0],
                3 => ['name' => 'Tuesday', 'total' => 0],
                4 => ['name' => 'Wednesday', 'total' => 0],
                5 => ['name' => 'Thursday', 'total' => 0],
                6 => ['name' => 'Friday', 'total' => 0],
                7 => ['name' => 'Saturday', 'total' => 0],
            ];

            // Fill in actual data
            foreach ($result as $item) {
                $days[$item->day_of_week]['total'] = round($item->total, 2);
            }

            return array_values($days);
        });
    }

    /**
     * Get monthly spending trend for this budget category.
     *
     * @return array
     */
    public function getMonthlyTrend($months = 6)
    {
        $cacheKey = "budget_monthly_trend_{$this->user_id}_{$this->category_id}_{$months}";

        return Cache::remember($cacheKey, now()->addHours(24), function () use ($months) {
            $endDate = Carbon::today();
            $startDate = Carbon::today()->subMonths($months);

            $result = Transaction::where('user_id', $this->user_id)
                ->where('category_id', $this->category_id)
                ->where('type', 'expense')
                ->whereBetween('date', [$startDate, $endDate])
                ->select(
                    DB::raw('YEAR(date) as year'),
                    DB::raw('MONTH(date) as month'),
                    DB::raw('SUM(amount) as total')
                )
                ->groupBy('year', 'month')
                ->orderBy('year')
                ->orderBy('month')
                ->get();

            // Create array of all months in range
            $trend = [];
            $currentDate = clone $startDate;

            while ($currentDate <= $endDate) {
                $year = $currentDate->year;
                $month = $currentDate->month;
                $monthName = $currentDate->format('M Y');

                $trend[$year . '-' . $month] = [
                    'month' => $monthName,
                    'total' => 0
                ];

                $currentDate->addMonth();
            }

            // Fill in actual data
            foreach ($result as $item) {
                $key = $item->year . '-' . $item->month;
                if (isset($trend[$key])) {
                    $trend[$key]['total'] = round($item->total, 2);
                }
            }

            return array_values($trend);
        });
    }

    /**
     * Get spending breakdown by subcategories (if applicable).
     *
     * @return array
     */
    public function getSubcategoryBreakdown()
    {
        // This would require a subcategory relationship which isn't implemented yet
        // For now, we'll return a placeholder
        return [];
    }

    /**
     * Get daily spending data for charts.
     *
     * @return array
     */
    public function getDailySpendingData()
    {
        $cacheKey = "budget_daily_spending_{$this->id}";

        return Cache::remember($cacheKey, now()->addHours(6), function () {
            $startDate = $this->start_date;
            $endDate = $this->end_date;

            // Get daily spending
            $dailySpending = Transaction::where('user_id', $this->user_id)
                ->where('category_id', $this->category_id)
                ->where('type', 'expense')
                ->whereBetween('date', [$startDate, $endDate])
                ->select(DB::raw('DATE(date) as day'), DB::raw('SUM(amount) as total'))
                ->groupBy('day')
                ->get()
                ->keyBy('day')
                ->map(function ($item) {
                    return round($item->total, 2);
                });

            // Create a complete date range with zeros for days without spending
            $dateRange = [];
            $currentDate = clone $startDate;

            while ($currentDate->lte($endDate)) {
                $dateKey = $currentDate->format('Y-m-d');
                $dateRange[$dateKey] = $dailySpending[$dateKey] ?? 0;
                $currentDate->addDay();
            }

            // Calculate cumulative spending
            $cumulativeSpending = [];
            $runningTotal = 0;

            foreach ($dateRange as $date => $amount) {
                $runningTotal += $amount;
                $cumulativeSpending[$date] = round($runningTotal, 2);
            }

            // Calculate ideal spending line (even distribution)
            $idealSpending = [];
            $dailyBudget = $this->amount / count($dateRange);
            $idealRunningTotal = 0;

            foreach ($dateRange as $date => $amount) {
                $idealRunningTotal += $dailyBudget;
                $idealSpending[$date] = round($idealRunningTotal, 2);
            }

            // Format dates for display
            $formattedDates = [];
            foreach (array_keys($dateRange) as $dateString) {
                $date = Carbon::parse($dateString);
                $formattedDates[] = $date->format('M j');
            }

            return [
                'dates' => $formattedDates,
                'daily' => array_values($dateRange),
                'cumulative' => array_values($cumulativeSpending),
                'ideal' => array_values($idealSpending)
            ];
        });
    }

    /**
     * Get a color code based on the budget status.
     *
     * @return string
     */
    public function getStatusColorAttribute()
    {
        switch ($this->status) {
            case 'over_budget':
                return '#ef4444'; // red
            case 'warning':
                return '#f59e0b'; // amber
            default:
                return '#10b981'; // green
        }
    }

    /**
     * Get a color code based on the spending pace.
     *
     * @return string
     */
    public function getSpendingPaceColorAttribute()
    {
        switch ($this->spending_pace) {
            case 'ahead':
                return '#ef4444'; // red
            case 'behind':
                return '#3b82f6'; // blue
            default:
                return '#10b981'; // green
        }
    }
}
