<?php

namespace App\Http\Controllers;

use App\Models\Goal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class GoalController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $goals = Auth::user()->goals()
            ->orderBy('priority', 'desc')
            ->orderBy('target_date', 'asc')
            ->get();
            
        return Inertia::render('Goals/Index', [
            'goals' => $goals,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return Inertia::render('Goals/Create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'target_amount' => 'required|integer|min:0',
            'current_amount' => 'nullable|integer|min:0',
            'target_date' => 'required|date|after:today',
            'priority' => 'required|in:low,medium,high',
        ]);
        
        $goal = Auth::user()->goals()->create($validated);
        
        return redirect()->route('goals.index')
            ->with('success', 'Goal created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Goal $goal)
    {   
        // Check if the goal belongs to the authenticated user
        if ($goal->user_id !== auth()->id()) {
            abort(404);
        }
        
        return Inertia::render('Goals/Show', [
            'goal' => $goal,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Goal $goal)
    {
        // Check if the goal belongs to the authenticated user
        if ($goal->user_id !== auth()->id()) {
            abort(404);
        }
        
        return Inertia::render('Goals/Edit', [
            'goal' => $goal,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Goal $goal)
    {
        // Check if the goal belongs to the authenticated user
        if ($goal->user_id !== auth()->id()) {
            abort(404);
        }
        
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'target_amount' => 'required|integer|min:0',
            'current_amount' => 'nullable|integer|min:0',
            'target_date' => 'required|date',
            'priority' => 'required|in:low,medium,high',
            'status' => 'required|in:in_progress,completed,cancelled',
        ]);
        
        $goal->update($validated);
        
        return redirect()->route('goals.index')
            ->with('success', 'Goal updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Goal $goal)
    {
        // Check if the goal belongs to the authenticated user
        if ($goal->user_id !== auth()->id()) {
            abort(404);
        }
        
        $goal->delete();
        
        return redirect()->route('goals.index')
            ->with('success', 'Goal deleted successfully.');
    }
    
    /**
     * Update the current amount of a goal.
     */
    public function updateAmount(Request $request, Goal $goal)
    {
        // Check if the goal belongs to the authenticated user
        if ($goal->user_id !== auth()->id()) {
            abort(404);
        }
        
        $validated = $request->validate([
            'amount' => 'required|integer|min:0',
            'operation' => 'required|in:add,subtract,set',
        ]);
        
        $currentAmount = $goal->current_amount;
        
        switch ($validated['operation']) {
            case 'add':
                $goal->current_amount = $currentAmount + $validated['amount'];
                break;
            case 'subtract':
                $goal->current_amount = max(0, $currentAmount - $validated['amount']);
                break;
            case 'set':
                $goal->current_amount = $validated['amount'];
                break;
        }
        
        // Check if goal is achieved and update status if needed
        if ($goal->current_amount >= $goal->target_amount && $goal->status === 'in_progress') {
            $goal->status = 'completed';
        }
        
        $goal->save();
        
        return redirect()->back()
            ->with('success', 'Goal amount updated successfully.');
    }
    
    /**
     * Display a summary of all goals.
     */
    public function summary()
    {
        $goals = Auth::user()->goals;
        
        $totalGoals = $goals->count();
        $completedGoals = $goals->where('status', 'completed')->count();
        $inProgressGoals = $goals->where('status', 'in_progress')->count();
        $cancelledGoals = $goals->where('status', 'cancelled')->count();
        
        $totalTargetAmount = $goals->sum('target_amount');
        $totalCurrentAmount = $goals->sum('current_amount');
        $overallProgress = $totalTargetAmount > 0 ? ($totalCurrentAmount / $totalTargetAmount) * 100 : 0;
        
        $upcomingGoals = $goals->where('status', 'in_progress')
            ->where('target_date', '>=', now())
            ->sortBy('target_date')
            ->take(5);
            
        return Inertia::render('Goals/Summary', [
            'statistics' => [
                'totalGoals' => $totalGoals,
                'completedGoals' => $completedGoals,
                'inProgressGoals' => $inProgressGoals,
                'cancelledGoals' => $cancelledGoals,
                'totalTargetAmount' => $totalTargetAmount,
                'totalCurrentAmount' => $totalCurrentAmount,
                'overallProgress' => round($overallProgress, 2),
            ],
            'upcomingGoals' => $upcomingGoals,
        ]);
    }
}
