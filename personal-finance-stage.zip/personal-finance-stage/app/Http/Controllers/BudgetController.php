<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Budget;
use App\Models\Category;
use App\Models\Transaction;
use Inertia\Inertia;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class BudgetController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $user = auth()->user();
        
        // Get filter parameters
        $categoryId = $request->input('category_id');
        $period = $request->input('period');
        $status = $request->input('status');
        $sortField = $request->input('sort_field', 'start_date');
        $sortDirection = $request->input('sort_direction', 'desc');
        
        // Start with a base query
        $budgetsQuery = $user->budgets()->with('category');
        
        // Apply filters if provided
        if ($categoryId) {
            $budgetsQuery->where('category_id', $categoryId);
        }
        
        if ($period) {
            $budgetsQuery->where('period', $period);
        }
        
        // Apply sorting
        $budgetsQuery->orderBy($sortField, $sortDirection);
        
        // Get the budgets
        $budgets = $budgetsQuery->get();
        
        // Apply status filter if provided (this needs to be done after fetching because it's a computed property)
        if ($status) {
            $budgets = $budgets->filter(function($budget) use ($status) {
                return $budget->status === $status;
            })->values();
        }

        // Get expense categories for creating new budgets
        $expenseCategories = $user->categories()->where('type', 'expense')->get();

        // Calculate overall budget statistics
        $totalBudgeted = $budgets->sum('amount');
        $totalSpent = $budgets->sum('spent');
        $overallProgress = $totalBudgeted > 0 ? min(100, round(($totalSpent / $totalBudgeted) * 100, 1)) : 0;

        // Get active budgets (current period)
        $activeBudgets = $budgets->filter(function($budget) {
            return Carbon::now()->between($budget->start_date, $budget->end_date);
        });

        return Inertia::render('Budgets/Index', [
            'budgets' => $budgets,
            'activeBudgets' => $activeBudgets->values(),
            'categories' => $expenseCategories,
            'filters' => [
                'category_id' => $categoryId,
                'period' => $period,
                'status' => $status,
                'sort_field' => $sortField,
                'sort_direction' => $sortDirection
            ],
            'stats' => [
                'totalBudgeted' => $totalBudgeted,
                'totalSpent' => $totalSpent,
                'overallProgress' => $overallProgress,
                'overBudgetCount' => $budgets->filter(function($budget) {
                    return $budget->isOverBudget();
                })->count(),
                'warningCount' => $budgets->filter(function($budget) {
                    return $budget->status === 'warning';
                })->count()
            ]
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $user = auth()->user();
        $expenseCategories = $user->categories()->where('type', 'expense')->get();

        return Inertia::render('Budgets/Create', [
            'categories' => $expenseCategories
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'category_id' => 'required|exists:categories,id',
            'amount' => 'required|numeric|min:0',
            'period' => 'required|in:monthly,quarterly,yearly',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date'
        ]);

        // Check if a budget already exists for this category and period
        $existingBudget = auth()->user()->budgets()
            ->where('category_id', $validated['category_id'])
            ->where(function($query) use ($validated) {
                $query->whereBetween('start_date', [$validated['start_date'], $validated['end_date']])
                    ->orWhereBetween('end_date', [$validated['start_date'], $validated['end_date']]);
            })->first();

        if ($existingBudget) {
            return back()->withErrors([
                'category_id' => 'A budget for this category already exists during the selected period.'
            ]);
        }

        auth()->user()->budgets()->create($validated);

        return redirect()->route('budgets.index')->with('success', 'Budget created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Budget $budget)
    {
        // Check if the budget belongs to the authenticated user
        if ($budget->user_id !== auth()->id()) {
            abort(404);
        }

        $budget->load('category');

        // Get transactions for this budget's category within the budget period
        $transactions = auth()->user()->transactions()
            ->where('category_id', $budget->category_id)
            ->where('type', 'expense')
            ->whereBetween('date', [$budget->start_date, $budget->end_date])
            ->latest()
            ->get();

        // Calculate spent amount
        $spent = $transactions->sum('amount');
        $remaining = max(0, $budget->amount - $spent);
        $progress = $budget->amount > 0 ? min(100, round(($spent / $budget->amount) * 100, 1)) : 0;

        // Determine status
        $status = 'on_track';
        $statusColor = 'green';
        
        if ($progress >= 100) {
            $status = 'over_budget';
            $statusColor = 'red';
        } elseif ($progress >= 80) {
            $status = 'warning';
            $statusColor = 'yellow';
        }

        return Inertia::render('Budgets/Show', [
            'budget' => $budget,
            'transactions' => $transactions,
            'stats' => [
                'spent' => $spent,
                'remaining' => $remaining,
                'progress' => $progress,
                'status' => $status,
                'statusColor' => $statusColor
            ]
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Budget $budget)
    {
        // Check if the budget belongs to the authenticated user
        if ($budget->user_id !== auth()->id()) {
            abort(404);
        }

        $user = auth()->user();
        $expenseCategories = $user->categories()->where('type', 'expense')->get();

        return Inertia::render('Budgets/Edit', [
            'budget' => $budget,
            'categories' => $expenseCategories
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Budget $budget)
    {
        // Check if the budget belongs to the authenticated user
        if ($budget->user_id !== auth()->id()) {
            abort(404);
        }

        $validated = $request->validate([
            'category_id' => 'required|exists:categories,id',
            'amount' => 'required|numeric|min:0',
            'period' => 'required|in:monthly,quarterly,yearly',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date'
        ]);

        // Check if another budget exists for this category and period (excluding this one)
        $existingBudget = auth()->user()->budgets()
            ->where('id', '!=', $budget->id)
            ->where('category_id', $validated['category_id'])
            ->where(function($query) use ($validated) {
                $query->whereBetween('start_date', [$validated['start_date'], $validated['end_date']])
                    ->orWhereBetween('end_date', [$validated['start_date'], $validated['end_date']]);
            })->first();

        if ($existingBudget) {
            return back()->withErrors([
                'category_id' => 'Another budget for this category already exists during the selected period.'
            ]);
        }

        $budget->update($validated);

        return redirect()->route('budgets.index')->with('success', 'Budget updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Budget $budget)
    {
        // Check if the budget belongs to the authenticated user
        if ($budget->user_id !== auth()->id()) {
            abort(404);
        }
        $budget->delete();

        return redirect()->route('budgets.index')->with('success', 'Budget deleted successfully.');
    }

    /**
     * Get budget summary for the dashboard.
     */
    public function summary()
    {
        $user = auth()->user();
        $currentBudgets = $user->budgets()
            ->with('category')
            ->whereDate('start_date', '<=', now())
            ->whereDate('end_date', '>=', now())
            ->get();

        $overBudgetCount = $currentBudgets->filter(function($budget) {
            return $budget->isOverBudget();
        })->count();

        $warningCount = $currentBudgets->filter(function($budget) {
            return $budget->status === 'warning';
        })->count();

        return response()->json([
            'activeBudgets' => $currentBudgets->count(),
            'overBudgetCount' => $overBudgetCount,
            'warningCount' => $warningCount,
            'topBudgets' => $currentBudgets->sortByDesc('progress')->take(3)->values()
        ]);
    }

    /**
     * Get budget analytics data for dashboard.
     */
    public function analytics()
    {
        $user = auth()->user();
        $currentMonth = Carbon::now()->format('Y-m');

        // Get active budgets
        $activeBudgets = $user->budgets()
            ->with('category')
            ->whereDate('start_date', '<=', now())
            ->whereDate('end_date', '>=', now())
            ->get();

        // Calculate overall budget statistics
        $totalBudgeted = $activeBudgets->sum('amount');
        $totalSpent = $activeBudgets->sum('spent');
        $overallProgress = $totalBudgeted > 0 ? min(100, round(($totalSpent / $totalBudgeted) * 100, 1)) : 0;

        // Get top spending categories for the current month
        $topCategories = $user->transactions()
            ->where('type', 'expense')
            ->whereYear('date', now()->year)
            ->whereMonth('date', now()->month)
            ->select('category_id', DB::raw('SUM(amount) as total'))
            ->groupBy('category_id')
            ->orderByDesc('total')
            ->limit(5)
            ->with('category')
            ->get()
            ->map(function($item) {
                return [
                    'category' => $item->category->name,
                    'color' => $item->category->color,
                    'total' => round($item->total, 2)
                ];
            });

        // Get monthly spending trend
        $monthlySpending = $user->transactions()
            ->where('type', 'expense')
            ->whereDate('date', '>=', now()->subMonths(6))
            ->select(
                DB::raw('YEAR(date) as year'),
                DB::raw('MONTH(date) as month'),
                DB::raw('SUM(amount) as total')
            )
            ->groupBy('year', 'month')
            ->orderBy('year')
            ->orderBy('month')
            ->get();

        // Format monthly spending data
        $monthlyTrend = [];
        for ($i = 5; $i >= 0; $i--) {
            $date = now()->subMonths($i);
            $yearMonth = $date->format('Y-n');
            $monthName = $date->format('M Y');

            $spending = $monthlySpending->first(function($item) use ($yearMonth) {
                return $item->year . '-' . $item->month === $yearMonth;
            });

            $monthlyTrend[] = [
                'month' => $monthName,
                'total' => $spending ? round($spending->total, 2) : 0
            ];
        }

        return response()->json([
            'budgetStats' => [
                'totalBudgeted' => $totalBudgeted,
                'totalSpent' => $totalSpent,
                'overallProgress' => $overallProgress,
                'activeBudgets' => $activeBudgets->count(),
                'overBudgetCount' => $activeBudgets->filter(function($budget) {
                    return $budget->isOverBudget();
                })->count(),
                'warningCount' => $activeBudgets->filter(function($budget) {
                    return $budget->status === 'warning';
                })->count()
            ],
            'topBudgets' => $activeBudgets->sortByDesc('progress')->take(3)->values(),
            'topCategories' => $topCategories,
            'monthlyTrend' => $monthlyTrend
        ]);
    }
}
