<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();
        
        // Get date range from request or use current month as default
        $startDate = $request->input('start_date') ? Carbon::parse($request->input('start_date')) : Carbon::now()->startOfMonth();
        $endDate = $request->input('end_date') ? Carbon::parse($request->input('end_date'))->endOfDay() : Carbon::now()->endOfMonth()->endOfDay();
        
        // Ensure end date is not before start date
        if ($endDate->lt($startDate)) {
            $endDate = (clone $startDate)->lastOfMonth();
        }
        
        // Format for display
        $dateRange = [
            'start_date' => $startDate->format('Y-m-d'),
            'end_date' => $endDate->format('Y-m-d')
        ];

        // Recent transactions (not filtered by date)
        $recentTransactions = $user->transactions()
            ->with('category')
            ->latest()
            ->take(5)
            ->get();
            
        // Filtered transactions for the data table
        $filteredTransactions = $user->transactions()
            ->with('category')
            ->whereBetween('date', [$startDate, $endDate])
            ->latest()
            ->get();

        $periodIncome = $user->transactions()
            ->where('type', 'income')
            ->whereBetween('date', [$startDate, $endDate])
            ->sum('amount');

        $periodExpense = $user->transactions()
            ->where('type', 'expense')
            ->whereBetween('date', [$startDate, $endDate])
            ->sum('amount');

        $categoryTotals = $user->transactions()
            ->whereBetween('date', [$startDate, $endDate])
            ->selectRaw('category_id, type, sum(amount) as total')
            ->groupBy('category_id', 'type')
            ->with('category')
            ->get();

        // Get active budgets
        $activeBudgets = $user->budgets()
            ->with('category')
            ->whereDate('start_date', '<=', now())
            ->whereDate('end_date', '>=', now())
            ->get();

        // Calculate budget statistics
        $overBudgetCount = $activeBudgets->filter(function($budget) {
            return $budget->isOverBudget();
        })->count();

        $warningCount = $activeBudgets->filter(function($budget) {
            return $budget->status === 'warning';
        })->count();

        // Get top 3 budgets by progress
        $topBudgets = $activeBudgets->sortByDesc('progress')->take(3)->values();
        
        // Get goals information
        $activeGoals = $user->goals()
            ->where('status', 'in_progress')
            ->orderBy('target_date', 'asc')
            ->get();
            
        $upcomingGoals = $activeGoals->take(3);
        
        $completedGoalsCount = $user->goals()
            ->where('status', 'completed')
            ->count();

        // Calculate period savings (income - expense)
        $periodSavings = $periodIncome - $periodExpense;
        $savingsRate = $periodIncome > 0 ? round(($periodSavings / $periodIncome) * 100, 1) : 0;

        return inertia('Dashboard', [
            'recentTransactions' => $recentTransactions,
            'filteredTransactions' => $filteredTransactions,
            'periodIncome' => $periodIncome,
            'periodExpense' => $periodExpense,
            'periodSavings' => $periodSavings,
            'savingsRate' => $savingsRate,
            'categoryTotals' => $categoryTotals,
            'budgetStats' => [
                'activeBudgets' => $activeBudgets->count(),
                'overBudgetCount' => $overBudgetCount,
                'warningCount' => $warningCount,
            ],
            'topBudgets' => $topBudgets,
            'dateRange' => $dateRange,
            'goalStats' => [
                'activeGoals' => $activeGoals->count(),
                'completedGoals' => $completedGoalsCount,
                'totalGoals' => $activeGoals->count() + $completedGoalsCount,
            ],
            'upcomingGoals' => $upcomingGoals
        ]);
    }
}
